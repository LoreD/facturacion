<?php 
/*
if(isset($_POST['query'])){ 
    $conexion = mysql_connect ("localhost", "root", ""); 
    mysql_select_db ("facturacion_electronica"); 
     
    $query= $_POST['query']; 
     
    $sql= mysql_query("SELECT * from c_claveprodserv WHERE c_ClaveProdServ LIKE '%{$query}%'"); 
    $array= array(); 
     
    while($row= mysql_fetch_assoc($sql)){ 
        $array= $row['c_ClaveProdServ'];
        $array= $row['Descripcion']; 
         
        echo json_encode($array); 
    } 
} */

    /*define (DB_USER, "root");
    define (DB_PASSWORD, "");
    define (DB_DATABASE, "facturacion_electronica");
    define (DB_HOST, "localhost");

    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);

    $sql = "SELECT * from c_claveprodserv  
            WHERE c_ClaveProdServ LIKE '%".$_GET['query']."%'
            LIMIT 10"; 

    $result = $mysqli->query($sql);

    $json = [];
    while($row = $result->fetch_assoc()){
         $json[] = $row['c_ClaveProdServ'];
    }

    echo json_encode($json);*/

    //CREDENTIALS FOR DB
    define ('DBSERVER', 'localhost');
    define ('DBUSER', 'root');
    define ('DBPASS','');
    define ('DBNAME','facturacion_electronica');

    //LET'S INITIATE CONNECT TO DB
    $connection = mysql_connect(DBSERVER, DBUSER, DBPASS) or die("Can't connect to server. Please check credentials and try again");
    $result = mysql_select_db(DBNAME) or die("Can't select database. Please check DB name and try again");

    //CREATE QUERY TO DB AND PUT RECEIVED DATA INTO ASSOCIATIVE ARRAY
    if (isset($_REQUEST['query'])) {
        $query = $_REQUEST['query'];
        $sql = mysql_query ("SELECT Descripcion, c_ClaveProdServ FROM c_claveprodserv WHERE c_ClaveProdServ LIKE '%{$query}%' OR Descripcion LIKE '%{$query}%'");
        $array = array();
        while ($row = mysql_fetch_array($sql)) {
            $array[] = array (
                'label' => $row['c_ClaveProdServ'].', '.$row['Descripcion'],
                'value' => $row['c_ClaveProdServ'].' '.$row['Descripcion'],
            );
        }
        //RETURN JSON ARRAY
        echo json_encode ($array);
    }

?>