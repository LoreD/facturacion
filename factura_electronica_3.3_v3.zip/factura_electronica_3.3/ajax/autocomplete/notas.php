$("#lineas_albaran").append("<tr id=\"linea_"+numlineas+"\">\n\
      <td width=\"200\"><b>Clave</b><input type=\"hidden\" name=\"idlinea_"+numlineas+"\" value=\"-1\"/>\n\
         <input type=\"text\" class=\"form-control\" id=\"referencia_"+numlineas+"\" name=\"referencia_"+numlineas+"\"/>\n\
         <input type=\"hidden\" name=\"codcombinacion_"+numlineas+"\"/>\n\
      <td width=\"100\"><b>Cantidad</b><input type=\""+input_number+"\" step=\"any\" id=\"cantidad_"+numlineas+"\" class=\"form-control text-right\" name=\"cantidad_"+numlineas+
         "\" onchange=\"recalcular()\" onkeyup=\"recalcular()\" autocomplete=\"off\" value=\"1\"/></td>\n\
      <td width=\"100\"><b>Unidad</b><input type=\"text\" class=\"form-control\" id=\"unidad_"+numlineas+"\" name=\"unidad_"+numlineas+"\"></td>\n\
      <td width=\"150\"><b>Clave Unidad</b><input type=\"text\" class=\"form-control\" id=\"claveU_"+numlineas+"\" name=\"claveU_"+numlineas+"\"></td>\n\
      <td width=\"200\"><b>Num. identificacion</b><input type=\"text\" class=\"form-control\" id=\"identificacion_"+numlineas+"\" name=\"identificacion_"+numlineas+"\"></td>\n\
      <td width=\"350\"><b>Descripcion</b><textarea class=\"form-control\" id=\"desc_"+numlineas+"\" name=\"desc_"+numlineas+"\" rows=\"1\"></textarea></td>\n\
      <td width=\"150\"><b>Valor unitario</b><input type=\"text\" class=\"form-control text-right\" id=\"pvp_"+numlineas+"\" name=\"pvp_"+numlineas+"\" value=\"0\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td width=\"115\"><b>Descuento</b><input type=\"text\" id=\"dto_"+numlineas+"\" name=\"dto_"+numlineas+"\" value=\"0\" class=\"form-control text-right\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td width=\"180\"><b>Importe</b><input type=\"text\" class=\"form-control text-right\" id=\"neto_"+numlineas+"\" name=\"neto_"+numlineas+
         "\" onchange=\"ajustar_neto("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\" readonly/></td>\n\
      "+aux_all_impuestos(numlineas,default_impuesto)+"\n\
      <td width=\"180\" class=\"warning\" title=\"Cálculo aproximado del total de la linea\">Total   <input type=\"text\" class=\"form-control text-right\" id=\"total_"+numlineas+"\" name=\"total_"+numlineas+
         "\" onchange=\"ajustar_total("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
         <td>-<button class=\"btn btn-sm btn-danger\" type=\"button\" onclick=\"$('#linea_"+numlineas+"').remove();recalcular();\">\n\
         <span class=\"glyphicon glyphicon-trash\"></span></button></td></tr>          ");






/*
 * This file is part of facturacion_base
 * Copyright (C) 2014-2017  Carlos Garcia Gomez  neorazorx@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

var numlineas = 0;
var fs_nf0 = 2;
var fs_nf0_art = 2;
var all_direcciones = [];
var all_impuestos = [];
var default_impuesto = '';
var all_series = [];
var cliente = false;
var nueva_venta_url = '';
var fin_busqueda1 = true;
var fin_busqueda2 = true;
var siniva = false;
var irpf = 0;
var solo_con_stock = true;

function usar_cliente(codcliente)
{
   if(nueva_venta_url !== '')
   {
      $.getJSON(nueva_venta_url, 'datoscliente='+codcliente, function(json) {
         cliente = json;
         document.f_buscar_articulos.codcliente.value = cliente.codcliente;
         if(cliente.regimeniva == 'Exento')
         {
            irpf = 0;
            for(var j=0; j<numlineas; j++)
            {
               if($("#linea_"+j).length > 0)
               {
                  $("#iva_"+j).val(0);
                  $("#recargo_"+j).val(0);
               }
            }
         }
         recalcular();
      });
   }
}

function usar_serie()
{
   for(var i=0; i<all_series.length; i++)
   {
      if(all_series[i].codserie == $("#codserie").val())
      {
         siniva = all_series[i].siniva;
         irpf = all_series[i].irpf;
         
         for(var j=0; j<numlineas; j++)
         {
            if($("#linea_"+j).length > 0)
            {
               if(siniva)
               {
                  $("#iva_"+j).val(0);
                  $("#recargo_"+j).val(0);
               }
            }
         }
         
         break;
      }
   }
}

function usar_almacen()
{
   document.f_buscar_articulos.codalmacen.value = $("#codalmacen").val();
}

function usar_divisa()
{
   document.f_buscar_articulos.coddivisa.value = $("#coddivisa").val();
}

function usar_direccion()
{
   for(var i=0; i<all_direcciones.length; i++)
   {
      if(all_direcciones[i].id == $('select[name="coddir"]').val())
      {
         $('select[name="codpais"]').val(all_direcciones[i].codpais);
         $('input[name="provincia"]').val(all_direcciones[i].provincia);
         $('input[name="ciudad"]').val(all_direcciones[i].ciudad);
         $('input[name="codpostal"]').val(all_direcciones[i].codpostal);
         $('input[name="direccion"]').val(all_direcciones[i].direccion);
         $('input[name="apartado"]').val(all_direcciones[i].apartado);
      }
   }
}

function usar_direccion_envio()
{
   for(var i=0; i<all_direcciones.length; i++)
   {
      if($('select[name="envio_coddir"]').val() == '')
      {
         $('input[name="envio_provincia"]').val('');
         $('input[name="envio_ciudad"]').val('');
         $('input[name="envio_codpostal"]').val('');
         $('input[name="envio_direccion"]').val('');
         $('input[name="envio_apartado"]').val('');
         break;
      }
      else if(all_direcciones[i].id == $('select[name="envio_coddir"]').val())
      {
         $('select[name="envio_codpais"]').val(all_direcciones[i].codpais);
         $('input[name="envio_provincia"]').val(all_direcciones[i].provincia);
         $('input[name="envio_ciudad"]').val(all_direcciones[i].ciudad);
         $('input[name="envio_codpostal"]').val(all_direcciones[i].codpostal);
         $('input[name="envio_direccion"]').val(all_direcciones[i].direccion);
         $('input[name="envio_apartado"]').val(all_direcciones[i].apartado);
      }
   }
}

function recalcular()
{
   var l_uds = 0;
   var l_pvp = 0;
   var l_dto = 0;
   var l_neto = 0;
   var l_iva = 0;
   var l_irpf = 0;
   var l_recargo = 0;
   var neto = 0;
   var total_iva = 0;
   var total_irpf = 0;
   var total_recargo = 0;
   
   for(var i=0; i<numlineas; i++)
   {
      if($("#linea_"+i).length > 0)
      {
         /// cambiamos coma por punto
         if( input_number == 'text' && $("#cantidad_"+i).val().search(",") >= 0 )
         {
            $("#cantidad_"+i).val( $("#cantidad_"+i).val().replace(",",".") );
         }
         if( $("#pvp_"+i).val().search(",") >= 0 )
         {
            $("#pvp_"+i).val( $("#pvp_"+i).val().replace(",",".") );
         }
         if( $("#dto_"+i).val().search(",") >= 0 )
         {
            $("#dto_"+i).val( $("#dto_"+i).val().replace(",",".") );
         }
         if( $("#iva_"+i).val().search(",") >= 0 )
         {
            $("#iva_"+i).val( $("#iva_"+i).val().replace(",",".") );
         }
         if( $("#irpf_"+i).val().search(",") >= 0 )
         {
            $("#irpf_"+i).val( $("#irpf_"+i).val().replace(",",".") );
         }
         if( $("#recargo_"+i).val().search(",") >= 0 )
         {
            $("#recargo_"+i).val( $("#recargo_"+i).val().replace(",",".") );
         }
         
         l_uds = parseFloat( $("#cantidad_"+i).val() );
         l_pvp = parseFloat( $("#pvp_"+i).val() );
         l_dto = parseFloat( $("#dto_"+i).val() );
         l_neto = l_uds*l_pvp*(100-l_dto)/100;
         l_iva = parseFloat( $("#iva_"+i).val() );
         l_irpf = parseFloat( $("#irpf_"+i).val() );
         l_recargo = parseFloat( $("#recargo_"+i).val() );
         
         $("#neto_"+i).val( l_neto );
         if(numlineas == 1)
         {
            $("#total_"+i).val( fs_round(l_neto, fs_nf0) + fs_round(l_neto*(l_iva-l_irpf+l_recargo)/100, fs_nf0) );
         }
         else
         {
            $("#total_"+i).val( number_format(l_neto + (l_neto*(l_iva-l_irpf+l_recargo)/100), fs_nf0, '.', '') );
         }
         
         neto += l_neto;
         total_iva += l_neto * l_iva/100;
         total_irpf += l_neto * l_irpf/100;
         total_recargo += l_neto * l_recargo/100;
         
         /// adaptamos el alto del textarea al texto
         var txt = $("textarea[name='desc_"+i+"']").val();
         txt = txt.split(/\r*\n/);
         if(txt.length > 1)
         {
            $("textarea[name='desc_"+i+"']").prop('rows', txt.length);
         }
      }
   }
   
   neto = fs_round(neto, fs_nf0);
   total_iva = fs_round(total_iva, fs_nf0);
   total_irpf = fs_round(total_irpf, fs_nf0);
   total_recargo = fs_round(total_recargo, fs_nf0);
   $("#aneto").html(neto);
   $("#aiva").html(total_iva);
   $("#are").html(total_recargo);
   $("#airpf").html(total_irpf);
   $("#atotal").val( fs_round(neto + total_iva - total_irpf + total_recargo, fs_nf0) );
   
   if(total_recargo == 0 && !cliente.recargo)
   {
      $(".recargo").hide();
   }
   else
   {
      $(".recargo").show();
   }
   
   if(total_irpf == 0 && irpf == 0)
   {
      $(".irpf").hide();
   }
   else
   {
      $(".irpf").show();
   }
}

function ajustar_neto(i)
{
   var l_uds = 0;
   var l_pvp = 0;
   var l_dto = 0;
   var l_neto = 0;
   
   if($("#linea_"+i).length > 0)
   {
      /// cambiamos coma por punto
      if( $("#neto_"+i).val().search(",") >= 0 )
      {
         $("#neto_"+i).val( $("#neto_"+i).val().replace(",",".") );
      }
      
      l_uds = parseFloat( $("#cantidad_"+i).val() );
      l_pvp = parseFloat( $("#pvp_"+i).val() );
      l_dto = parseFloat( $("#dto_"+i).val() );
      l_neto = parseFloat( $("#neto_"+i).val() );
      if( isNaN(l_neto) )
      {
         l_neto = 0;
      }
      else if(l_neto < 0)
      {
         l_neto = Math.abs(l_neto);
      }
      
      if( l_neto <= l_pvp*l_uds )
      {
         l_dto = 100 - 100*l_neto/(l_pvp*l_uds);
         if( isNaN(l_dto) )
         {
            l_dto = 0;
         }
         
         l_dto = fs_round(l_dto, 2);
      }
      else
      {
         l_dto = 0;
         l_pvp = 100*l_neto/(l_uds*(100-l_dto));
         if( isNaN(l_pvp) )
         {
            l_pvp = 0;
         }
         
         l_pvp = fs_round(l_pvp, fs_nf0_art);
      }
      
      $("#pvp_"+i).val(l_pvp);
      $("#dto_"+i).val(l_dto);
   }
   
   recalcular();
}

function ajustar_total(i)
{
   var l_uds = 0;
   var l_pvp = 0;
   var l_dto = 0;
   var l_iva = 0;
   var l_irpf = 0;
   var l_recargo = 0;
   var l_neto = 0;
   var l_total = 0;
   
   if($("#linea_"+i).length > 0)
   {
      /// cambiamos coma por punto
      if( $("#total_"+i).val().search(",") >= 0 )
      {
         $("#total_"+i).val( $("#total_"+i).val().replace(",",".") );
      }
      
      l_uds = parseFloat( $("#cantidad_"+i).val() );
      l_pvp = parseFloat( $("#pvp_"+i).val() );
      l_dto = parseFloat( $("#dto_"+i).val() );
      l_iva = parseFloat( $("#iva_"+i).val() );
      l_recargo = parseFloat( $("#recargo_"+i).val() );
      l_irpf = parseFloat( $("#irpf_"+i).val() );
      
      l_total = parseFloat( $("#total_"+i).val() );
      if( isNaN(l_total) )
      {
         l_total = 0;
      }
      else if(l_total < 0)
      {
         l_total = Math.abs(l_total);
      }
      
      if( l_total <= l_pvp*l_uds + (l_pvp*l_uds*(l_iva-l_irpf+l_recargo)/100) )
      {
         l_neto = 100*l_total/(100+l_iva-l_irpf+l_recargo);
         l_dto = 100 - 100*l_neto/(l_pvp*l_uds);
         if( isNaN(l_dto) )
         {
            l_dto = 0;
         }
         
         l_dto = fs_round(l_dto, 2);
      }
      else
      {
         l_dto = 0;
         l_neto = 100*l_total/(100+l_iva-l_irpf+l_recargo);
         l_pvp = fs_round(l_neto/l_uds, fs_nf0_art);
      }
      
      $("#pvp_"+i).val(l_pvp);
      $("#dto_"+i).val(l_dto);
   }
   
   recalcular();
}

function ajustar_iva(num)
{
   if($("#linea_"+num).length > 0)
   {
      if(cliente.regimeniva == 'Exento')
      {
         $("#iva_"+num).val(0);
         $("#recargo_"+num).val(0);
         
         bootbox.alert({
            message: 'El cliente tiene regimen de IVA: '+cliente.regimeniva,
            title: "<b>Atención</b>"
         });
      }
      else if(siniva && $("#iva_"+num).val() != 0)
      {
         $("#iva_"+num).val(0);
         $("#recargo_"+num).val(0);
         
         bootbox.alert({
            message: 'La serie selecciona es sin IVA.',
            title: "<b>Atención</b>"
         });
      }
      else if(cliente.recargo)
      {
         for(var i=0; i<all_impuestos.length; i++)
         {
            if($("#iva_"+num).val() == all_impuestos[i].iva)
            {
               $("#recargo_"+num).val(all_impuestos[i].recargo);
            }
         }
      }
   }
   
   recalcular();
}

function aux_all_impuestos(num,codimpuesto)
{
   var iva = 0;
   var recargo = 0;
   if(cliente.regimeniva != 'Exento' && !siniva)
   {
      for(var i=0; i<all_impuestos.length; i++)
      {
         if(all_impuestos[i].codimpuesto == codimpuesto || codimpuesto == '')
         {
            iva = all_impuestos[i].iva;
            if(cliente.recargo)
            {
              recargo = all_impuestos[i].recargo;
            }
            break;
         }
      }
   }
   
   var html = "<td width=\"200\"><b>Iva</b><select id=\"iva_"+num+"\" class=\"form-control\" name=\"iva_"+num+"\" onchange=\"ajustar_iva('"+num+"')\">";
   for(var i=0; i<all_impuestos.length; i++)
   {
      if(iva == all_impuestos[i].iva)
      {
         html += "<option value=\""+all_impuestos[i].iva+"\" selected=\"\">"+all_impuestos[i].codimpuesto+" "+all_impuestos[i].descripcion+"</option>";
      }
      else
         html += "<option value=\""+all_impuestos[i].iva+"\">"+all_impuestos[i].codimpuesto+" "+all_impuestos[i].descripcion+"</option>";
   }
   html += "</select></td>";
   
   html += "<td class=\"recargo\"><input type=\"text\" class=\"form-control text-right\" id=\"recargo_"+num+"\" name=\"recargo_"+num+
           "\" value=\""+recargo+"\" onclick=\"this.select()\" onkeyup=\"recalcular()\" autocomplete=\"off\"/></td>";
   
   html += "<td class=\"irpf\"><input type=\"text\" class=\"form-control text-right\" id=\"irpf_"+num+"\" name=\"irpf_"+num+
         "\" value=\""+irpf+"\" onclick=\"this.select()\" onkeyup=\"recalcular()\" autocomplete=\"off\"/></td>";
   
   return html;
}

function add_articulo(ref,desc,pvp,dto,codimpuesto,cantidad,codcombinacion)
{
   if(typeof codcombinacion == 'undefined')
   {
      codcombinacion = '';
   }
   
   desc = Base64.decode(desc);
   $("#lineas_albaran").append("<tr id=\"linea_"+numlineas+"\">\n\
      <td><input type=\"hidden\" name=\"idlinea_"+numlineas+"\" value=\"-1\"/>\n\
         <input type=\"hidden\" name=\"referencia_"+numlineas+"\" value=\""+ref+"\"/>\n\
         <input type=\"hidden\" name=\"codcombinacion_"+numlineas+"\" value=\""+codcombinacion+"\"/>\n\
         <div class=\"form-control\"><small><a target=\"_blank\" href=\"index.php?page=ventas_articulo&ref="+ref+"\">"+ref+"</a></small></div></td>\n\
      <td><textarea class=\"form-control\" id=\"desc_"+numlineas+"\" name=\"desc_"+numlineas+"\" rows=\"1\">"+desc+"</textarea></td>\n\
      <td><input type=\""+input_number+"\" step=\"any\" id=\"cantidad_"+numlineas+"\" class=\"form-control text-right\" name=\"cantidad_"+numlineas+
         "\" onchange=\"recalcular()\" onkeyup=\"recalcular()\" autocomplete=\"off\" value=\""+cantidad+"\"/></td>\n\
      <td><button class=\"btn btn-sm btn-danger\" type=\"button\" onclick=\"$('#linea_"+numlineas+"').remove();recalcular();\">\n\
         <span class=\"glyphicon glyphicon-trash\"></span></button></td>\n\
      <td><input type=\"text\" class=\"form-control text-right\" id=\"pvp_"+numlineas+"\" name=\"pvp_"+numlineas+"\" value=\""+pvp+
         "\" onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td><input type=\"text\" id=\"dto_"+numlineas+"\" name=\"dto_"+numlineas+"\" value=\""+dto+
         "\" class=\"form-control text-right\" onkeyup=\"recalcular()\" onchange=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td><input type=\"text\" class=\"form-control text-right\" id=\"neto_"+numlineas+"\" name=\"neto_"+numlineas+
         "\" onchange=\"ajustar_neto("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      "+aux_all_impuestos(numlineas,codimpuesto)+"\n\
      <td class=\"warning\" title=\"Cálculo aproximado del total de la linea\">\n\
         <input type=\"text\" class=\"form-control text-right\" id=\"total_"+numlineas+"\" name=\"total_"+numlineas+
         "\" onchange=\"ajustar_total("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td></tr>");
   numlineas += 1;
   $("#numlineas").val(numlineas);
   recalcular();
   
   $("#modal_articulos").modal('hide');
   
   $("#desc_"+(numlineas-1)).select();
   return false;
}

function add_articulo_atributos(ref,desc,pvp,dto,codimpuesto,cantidad)
{
   if(nueva_venta_url !== '')
   {
      $.ajax({
         type: 'POST',
         url: nueva_venta_url,
         dataType: 'html',
         data: "referencia4combi="+ref+"&desc="+desc+"&pvp="+pvp+"&dto="+dto
                 +"&codimpuesto="+codimpuesto+"&cantidad="+cantidad,
         success: function(datos) {
            $("#nav_articulos").hide();
            $("#search_results").html(datos);
         },
         error: function() {
            bootbox.alert({
               message: 'Se ha producido un error al obtener los atributos.',
               title: "<b>Atención</b>"
            });
         }
      });
   }
}


/*function autocomplete(){
                  $("#referencia_").autocomplete({
                     source: "./ajax/autocomplete/claveproducto.php",
                     minLength: 2,
                     select: function(event, ui) {
                        event.preventDefault();
                        $('#idlinea_').val(ui.item.idlinea_);
                        $('#referencia_').val(ui.item.referencia_);
                        $('#tel1').val(ui.item.telefono_cliente);
                        $('#mail').val(ui.item.email_cliente);
                                                
                        
                      }
                  });
                   
                  
               });
               
   $("#referencia_" ).on( "keydown", function( event ) {
                  if (event.keyCode== $.ui.keyCode.LEFT || event.keyCode== $.ui.keyCode.RIGHT || event.keyCode== $.ui.keyCode.UP || event.keyCode== $.ui.keyCode.DOWN || event.keyCode== $.ui.keyCode.DELETE || event.keyCode== $.ui.keyCode.BACKSPACE )
                  {
                     $("#idlinea_" ).val("");
                     $("#tel1" ).val("");
                     $("#mail" ).val("");
                                 
                  }
                  if (event.keyCode==$.ui.keyCode.DELETE){
                     $("#referencia_" ).val("");
                     $("#idlinea_" ).val("");
                     $("#tel1" ).val("");
                     $("#mail" ).val("");
                  }
         });  
}*/

function add_linea_libre()
{
   $("#lineas_albaran").append("<div id=\"linea_"+numlineas+"\">\n\
      <div class=\"container-fluid\" style=\"margin-top: 10px;\">\n\
         <div class=\"row\">\n\
            <div class=\"col-sm-3\">\n\
               <div class=\"form-group\">\n\
                  Clave de producto o servicio: <span style=\"color:red\">*</span> \n\
                  <input type=\"hidden\" name=\"idlinea_"+numlineas+"\" value=\"-1\"/>\n\
                  <input type=\"hidden\" name=\"codcombinacion_"+numlineas+"\"/>\n\
                  <input type=\"text\" class=\"form-control\" id=\"referencia_"+numlineas+"\" name=\"referencia_"+numlineas+"\"/>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Cantidad \n\
                  <input type=\""+input_number+"\" step=\"any\" id=\"cantidad_"+numlineas+"\" class=\"form-control text-right\" name=\"cantidad_"+numlineas+
                  "\" onchange=\"recalcular()\" onkeyup=\"recalcular()\" autocomplete=\"off\" value=\"1\"/>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                 Clave Unidad <span style=\"color:red\">*</span>\n\
                 <input type=\"text\" class=\"form-control\" id=\"unidad_"+numlineas+"\" name=\"unidad_"+numlineas+"\">\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Num. identificacion\n\
                  <input type=\"text\" class=\"form-control\" id=\"identificacion_"+numlineas+"\" name=\"identificacion_"+numlineas+"\">\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-3\">\n\
               <div class=\"form-group\">\n\
                  Descripcion \n\
                  <textarea class=\"form-control\" id=\"desc_"+numlineas+"\" name=\"desc_"+numlineas+"\" rows=\"1\"></textarea>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Valor unitario \n\
                  <input type=\"text\" class=\"form-control text-right\" id=\"pvp_"+numlineas+"\" name=\"pvp_"+numlineas+"\" value=\"0\"\n\
                  onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Descuento\n\
                  <input type=\"text\" id=\"dto_"+numlineas+"\" name=\"dto_"+numlineas+"\" value=\"0\" class=\"form-control text-right\"\n\
                  onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Importe \n\
                  <input type=\"text\" class=\"form-control text-right\" id=\"neto_"+numlineas+"\" name=\"neto_"+numlineas+
         "        \" onchange=\"ajustar_neto("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\" readonly/>\n\
               </div>\n\
            </div>\n\
          </div>\n\
          <div class=\"row\">\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                   "+aux_all_impuestos(numlineas,default_impuesto)+"\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  Total \n\
                  <input type=\"text\" class=\"form-control text-right\" id=\"total_"+numlineas+"\" name=\"total_"+numlineas+
                  "\" onchange=\"ajustar_total("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/>\n\
               </div>\n\
            </div>\n\
            <div class=\"col-sm-2\">\n\
               <div class=\"form-group\">\n\
                  <button class=\"btn btn-sm btn-danger\" type=\"button\" onclick=\"$('#linea_"+numlineas+"').remove();recalcular();\">\n\
                  <span class=\"glyphicon glyphicon-trash\"></span></button>\n\
               </div>\n\
            </div>\n\
            </div>       </div>");

/*$("#lineas_albaran").append("<tr id=\"linea_"+numlineas+"\">\n\
      <td width=\"200\"><b>Clave</b><input type=\"hidden\" name=\"idlinea_"+numlineas+"\" value=\"-1\"/>\n\
         <input type=\"text\" class=\"form-control\" id=\"referencia_"+numlineas+"\" name=\"referencia_"+numlineas+"\"/>\n\
         <input type=\"hidden\" name=\"codcombinacion_"+numlineas+"\"/>\n\
      <td width=\"100\"><b>Cantidad</b><input type=\""+input_number+"\" step=\"any\" id=\"cantidad_"+numlineas+"\" class=\"form-control text-right\" name=\"cantidad_"+numlineas+
         "\" onchange=\"recalcular()\" onkeyup=\"recalcular()\" autocomplete=\"off\" value=\"1\"/></td>\n\
      <td width=\"100\"><b>Unidad</b><input type=\"text\" class=\"form-control\" id=\"unidad_"+numlineas+"\" name=\"unidad_"+numlineas+"\"></td>\n\
      <td width=\"150\"><b>Clave Unidad</b><input type=\"text\" class=\"form-control\" id=\"claveU_"+numlineas+"\" name=\"claveU_"+numlineas+"\"></td>\n\
      <td width=\"200\"><b>Num. identificacion</b><input type=\"text\" class=\"form-control\" id=\"identificacion_"+numlineas+"\" name=\"identificacion_"+numlineas+"\"></td>\n\
      <td width=\"350\"><b>Descripcion</b><textarea class=\"form-control\" id=\"desc_"+numlineas+"\" name=\"desc_"+numlineas+"\" rows=\"1\"></textarea></td>\n\
      <td width=\"150\"><b>Valor unitario</b><input type=\"text\" class=\"form-control text-right\" id=\"pvp_"+numlineas+"\" name=\"pvp_"+numlineas+"\" value=\"0\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td width=\"115\"><b>Descuento</b><input type=\"text\" id=\"dto_"+numlineas+"\" name=\"dto_"+numlineas+"\" value=\"0\" class=\"form-control text-right\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td width=\"180\"><b>Importe</b><input type=\"text\" class=\"form-control text-right\" id=\"neto_"+numlineas+"\" name=\"neto_"+numlineas+
         "\" onchange=\"ajustar_neto("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\" readonly/></td>\n\
      "+aux_all_impuestos(numlineas,default_impuesto)+"\n\
      <td width=\"180\" class=\"warning\" title=\"Cálculo aproximado del total de la linea\">Total   <input type=\"text\" class=\"form-control text-right\" id=\"total_"+numlineas+"\" name=\"total_"+numlineas+
         "\" onchange=\"ajustar_total("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
         <td>-<button class=\"btn btn-sm btn-danger\" type=\"button\" onclick=\"$('#linea_"+numlineas+"').remove();recalcular();\">\n\
         <span class=\"glyphicon glyphicon-trash\"></span></button></td></tr>          ");*/





     /*    <tr id=\"linea_"+numlineas+"\">\n\
      <td><input type=\"text\" class=\"form-control\" id=\"referencia_"+numlineas+"\" name=\"referencia_"+numlineas+"\"/>\n\
      <td><input type=\""+input_number+"\" step=\"any\" id=\"cantidad_"+numlineas+"\" class=\"form-control text-right\" name=\"cantidad_"+numlineas+
         "\" onchange=\"recalcular()\" onkeyup=\"recalcular()\" autocomplete=\"off\" value=\"1\"/></td>\n\
      <td><input type=\"text\" class=\"form-control\" id=\"unidad_"+numlineas+"\" name=\"unidad_"+numlineas+"\"></td>\n\
      <td><input type=\"text\" class=\"form-control\" id=\"claveU_"+numlineas+"\" name=\"claveU_"+numlineas+"\"></td>\n\
      <td><input type=\"text\" class=\"form-control\" id=\"identificacion_"+numlineas+"\" name=\"identificacion_"+numlineas+"\"></td>\n\
      <td><textarea class=\"form-control\" id=\"desc_"+numlineas+"\" name=\"desc_"+numlineas+"\" rows=\"1\"></textarea></td>\n\
      <td><input type=\"text\" class=\"form-control text-right\" id=\"pvp_"+numlineas+"\" name=\"pvp_"+numlineas+"\" value=\"0\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td><input type=\"text\" id=\"dto_"+numlineas+"\" name=\"dto_"+numlineas+"\" value=\"0\" class=\"form-control text-right\"\n\
          onkeyup=\"recalcular()\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      <td><input type=\"text\" class=\"form-control text-right\" id=\"neto_"+numlineas+"\" name=\"neto_"+numlineas+
         "\" onchange=\"ajustar_neto("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
      "+aux_all_impuestos(numlineas,default_impuesto)+"\n\
      <td class=\"warning\" title=\"Cálculo aproximado del total de la linea\">\n\
         <input type=\"text\" class=\"form-control text-right\" id=\"total_"+numlineas+"\" name=\"total_"+numlineas+
         "\" onchange=\"ajustar_total("+numlineas+")\" onclick=\"this.select()\" autocomplete=\"off\"/></td>\n\
         <td><button class=\"btn btn-sm btn-danger\" type=\"button\" onclick=\"$('#linea_"+numlineas+"').remove();recalcular();\">\n\
         <span class=\"glyphicon glyphicon-trash\"></span></button></td></tr>");*/
   numlineas += 1;
   $("#numlineas").val(numlineas);
   recalcular();
   //selecciona la casilla de referencia para introducir 
   $("#referencia_"+(numlineas-1)).select();
   return false;
}

function get_precios(ref)
{
   if(nueva_venta_url !== '')
   {
      $.ajax({
         type: 'POST',
         url: nueva_venta_url,
         dataType: 'html',
         data: "referencia4precios="+ref+"&codcliente="+cliente.codcliente,
         success: function(datos) {
            $("#nav_articulos").hide();
            $("#search_results").html(datos);
         },
         error: function() {
            bootbox.alert({
               message: 'Se ha producido un error al obtener los precios.',
               title: "<b>Atención</b>"
            });
         }
      });
   }
}

function new_articulo()
{
   if(nueva_venta_url !== '')
   {
      $.ajax({
         type: 'POST',
         url: nueva_venta_url+'&new_articulo=TRUE',
         dataType: 'json',
         data: $("form[name=f_nuevo_articulo]").serialize(),
         success: function(datos) {
            if(typeof datos[0] == 'undefined')
            {
               bootbox.alert({
                  message: 'Se ha producido un error al crear el artículo.',
                  title: "<b>Atención</b>"
               });
            }
            else
            {
               document.f_buscar_articulos.query.value = document.f_nuevo_articulo.referencia.value;
               $("#nav_articulos li").each(function() {
                  $(this).removeClass("active");
               });
               $("#li_mis_articulos").addClass('active');
               $("#search_results").show();
               $("#nuevo_articulo").hide();
               
               add_articulo(datos[0].referencia, Base64.encode(datos[0].descripcion), datos[0].pvp, 0, datos[0].codimpuesto, 1);
            }
         },
         error: function() {
            bootbox.alert({
               message: 'Se ha producido un error al crear el artículo.',
               title: "<b>Atención</b>"
            });
         }
      });
   }
}

function buscar_articulos()
{
   document.f_nuevo_articulo.referencia.value = document.f_buscar_articulos.query.value;
   
   if(document.f_buscar_articulos.query.value === '')
   {
      $("#nav_articulos").hide();
      $("#search_results").html('');
      $("#nuevo_articulo").hide();
      
      fin_busqueda1 = true;
      fin_busqueda2 = true;
   }
   else
   {
      $("#nav_articulos").show();
      
      if(nueva_venta_url !== '')
      {
         fin_busqueda1 = false;
         $.getJSON(nueva_venta_url, $("form[name=f_buscar_articulos]").serialize(), function(json) {
            var items = [];
            var insertar = false;
            $.each(json, function(key, val) {
               var stock = val.stockalm;
               if(val.nostock)
               {
                  stock = '-';
               }
               else if(val.stockalm != val.stockfis)
               {
                  stock += ' <span title="stock general">('+val.stockfis+')</span>';
               }
               
               var descripcion = Base64.encode(val.descripcion);
               var descripcion_visible = val.descripcion;
               if(val.codfamilia)
               {
                  descripcion_visible += ' <span class="label label-default" title="Familia: '+val.codfamilia+'">'
                          +val.codfamilia+'</span>';
               }
               if(val.codfabricante)
               {
                  descripcion_visible += ' <span class="label label-default" title="Fabricante: '+val.codfabricante+'">'
                          +val.codfabricante+'</span>';
               }
               if(val.trazabilidad)
               {
                  descripcion_visible += ' &nbsp; <i class="fa fa-code-fork" aria-hidden="true" title="Trazabilidad activada"></i>';
               }
               
               var tr_aux = '<tr>';
               if( val.bloqueado || (val.stockalm < 1 && !val.controlstock) )
               {
                  tr_aux = "<tr class=\"danger\">";
               }
               else if(val.stockfis < val.stockmin)
               {
                  tr_aux = "<tr class=\"warning\">";
               }
               else if(val.stockalm > 0)
               {
                  tr_aux = "<tr class=\"success\">";
               }
               
               if(val.sevende)
               {
                  var funcion = "add_articulo('"+val.referencia+"','"+descripcion+"','"+val.pvp+"','"
                          +val.dtopor+"','"+val.codimpuesto+"','"+val.cantidad+"')";
                  
                  if(val.tipo)
                  {
                     funcion = "add_articulo_"+val.tipo+"('"+val.referencia+"','"+descripcion+"','"
                             +val.pvp+"','"+val.dtopor+"','"+val.codimpuesto+"','"+val.cantidad+"')";
                  }
                  
                  items.push(tr_aux+"<td><a href=\"#\" onclick=\"get_precios('"+val.referencia+"')\" title=\"más detalles\">\n\
                     <span class=\"glyphicon glyphicon-eye-open\"></span></a>\n\
                     &nbsp; <a href=\"#\" onclick=\"return "+funcion+"\">"+val.referencia+'</a> '+descripcion_visible+"</td>\n\
                     <td class=\"text-right\"><a href=\"#\" onclick=\"return "+funcion+"\" title=\"actualizado el "+val.factualizado
                       +"\">"+show_precio(val.pvp*(100-val.dtopor)/100, val.coddivisa)+"</a></td>\n\
                     <td class=\"text-right\"><a href=\"#\" onclick=\"return "+funcion+"\" title=\"actualizado el "+val.factualizado
                       +"\">"+show_pvp_iva(val.pvp*(100-val.dtopor)/100 ,val.codimpuesto, val.coddivisa)+"</a></td>\n\
                     <td class=\"text-right\">"+stock+"</td></tr>");
               }
               
               if(val.query == document.f_buscar_articulos.query.value)
               {
                  insertar = true;
                  fin_busqueda1 = true;
               }
            });
            
            if(items.length == 0 && !fin_busqueda1)
            {
               items.push("<tr><td colspan=\"4\" class=\"warning\">Sin resultados. Usa la pestaña\n\
                              <b>Nuevo</b> para crear uno.</td></tr>");
               document.f_nuevo_articulo.referencia.value = document.f_buscar_articulos.query.value;
               insertar = true;
            }
            
            if(insertar)
            {
               $("#search_results").html("<div class=\"table-responsive\"><table class=\"table table-hover\"><thead><tr>\n\
                  <th class=\"text-left\">Referencia + descripción</th>\n\
                  <th class=\"text-right\" width=\"80\">Precio</th>\n\
                  <th class=\"text-right\" width=\"80\">Precio+IVA</th>\n\
                  <th class=\"text-right\" width=\"80\">Stock</th>\n\
                  </tr></thead>"+items.join('')+"</table></div>");
            }
         });
      }
   }
}


/*function buscar_claves()
{
   document.f_nueva_clave.referencia.value = document.f_buscar_claves.query.value;
   
   if(document.f_buscar_claves.query.value === '')
   {
      $("#nav_claves").hide();
      $("#search_results").html('');
      $("#nueva_clave").hide();
      
      fin_busqueda1 = true;
      fin_busqueda2 = true;
   }
   else
   {
      $("#nav_claves").show();
      
      if(nueva_venta_url !== '')
      {
         fin_busqueda1 = false;
         $.getJSON(nueva_venta_url, $("form[name=f_buscar_claves]").serialize(), function(json) {
            var items = [];
            var insertar = false;
            $.each(json, function(key, val) {
               if(val.query == document.f_buscar_claves.query.value)
               {
                  insertar = true;
                  fin_busqueda1 = true;
               }
            });
            
            if(items.length == 0 && !fin_busqueda1)
            {
               items.push("<tr><td colspan=\"4\" class=\"warning\">Sin resultados. Usa la pestaña\n\
                              <b>Nuevo</b> para crear uno.</td></tr>");
               document.f_nueva_clave.referencia.value = document.f_buscar_claves.query.value;
               insertar = true;
            }
         });
      }
   }
}*/

function show_pvp_iva(pvp,codimpuesto,coddivisa)
{
   var iva = 0;
   if(cliente.regimeniva != 'Exento' && !siniva)
   {
      for(var i=0; i<all_impuestos.length; i++)
      {
         if(all_impuestos[i].codimpuesto == codimpuesto)
         {
            iva = all_impuestos[i].iva;
            break;
         }
      }
   }
   
   return show_precio(pvp + pvp*iva/100, coddivisa);
}

$(document).ready(function() {
   $("#i_new_line").click(function() {
      $("#i_new_line").val("");
      $("#nav_articulos li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_articulos").addClass('active');
      $("#search_results").show();
      $("#nuevo_articulo").hide();
      $("#modal_articulos").modal('show');
      document.f_buscar_articulos.query.select();
   });
   
   $("#i_new_line").keyup(function() {
      document.f_buscar_articulos.query.value = $("#i_new_line").val();
      $("#i_new_line").val('');
      $("#nav_articulos li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_articulos").addClass('active');
      $("#search_results").html('');
      $("#search_results").show();
      $("#nuevo_articulo").hide();
      $("#modal_articulos").modal('show');
      document.f_buscar_articulos.query.select();
      buscar_articulos();
   });
   
   $("#f_buscar_articulos").keyup(function() {
      buscar_articulos();
   });
   
   $("#f_buscar_articulos").submit(function(event) {
      event.preventDefault();
      buscar_articulos();
   });
   
   $("#b_mis_articulos").click(function(event) {
      event.preventDefault();
      $("#nav_articulos li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_articulos").addClass('active');
      $("#nuevo_articulo").hide();
      $("#search_results").show();
      document.f_buscar_articulos.query.focus();
   });
   
   $("#b_nuevo_articulo").click(function(event) {
      event.preventDefault();
      $("#nav_articulos li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_nuevo_articulo").addClass('active');
      $("#search_results").hide();
      $("#nuevo_articulo").show();
      document.f_nuevo_articulo.referencia.select();
   });




   //claves
   /*$("#i_new_line").click(function() {
      $("#i_new_line").val("");
      $("#nav_claves li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_claves").addClass('active');
      $("#search_results").show();
      $("#nuevo_clave").hide();
      $("#modal_claves").modal('show');
      document.f_buscar_claves.query.select();
   });
   
   $("#i_new_line").keyup(function() {
      document.f_buscar_claves.query.value = $("#i_new_line").val();
      $("#i_new_line").val('');
      $("#nav_claves li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_claves").addClass('active');
      $("#search_results").html('');
      $("#search_results").show();
      $("#nuevo_clave").hide();
      $("#modal_claves").modal('show');
      document.f_buscar_claves.query.select();
      buscar_claves();
   });
   
   $("#f_buscar_claves").keyup(function() {
      buscar_claves();
   });
   
   $("#f_buscar_claves").submit(function(event) {
      event.preventDefault();
      buscar_claves();
   });
   
   $("#b_mis_claves").click(function(event) {
      event.preventDefault();
      $("#nav_claves li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_mis_claves").addClass('active');
      $("#nuevo_clave").hide();
      $("#search_results").show();
      document.f_buscar_claves.query.focus();
   });
   
   $("#b_nuevo_clave").click(function(event) {
      event.preventDefault();
      $("#nav_claves li").each(function() {
         $(this).removeClass("active");
      });
      $("#li_nuevo_clave").addClass('active');
      $("#search_results").hide();
      $("#nuevo_clave").show();
      document.f_nuevo_clave.referencia.select();
   });*/
});






<?php

/*
 * This file is part of facturacion_base
 * Copyright (C) 2014-2017  Carlos Garcia Gomez       neorazorx@gmail.com
 * Copyright (C) 2014-2015  Francesc Pineda Segarra   shawe.ewahs@gmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

require_once 'plugins/facturacion_base/extras/fbase_controller.php';
require_model('agencia_transporte.php');
require_model('almacen.php');
require_model('articulo.php');
require_model('articulo_combinacion.php');
require_model('asiento_factura.php');
require_model('divisa.php');
require_model('fabricante.php');
require_model('familia.php');
require_model('forma_pago.php');
require_model('grupo_clientes.php');
require_model('impuesto.php');
require_model('pais.php');
require_model('pedido_cliente.php');
require_model('presupuesto_cliente.php');
require_model('regularizacion_iva.php');
require_model('serie.php');
require_model('tarifa.php');

require_model('usoCFDI.php');
require_model('metodoPago.php');
require_model('claveProdServ.php');

class nueva_venta extends fbase_controller {

    public $agencia;
    public $agente;
    public $almacen;
    public $articulo;
    public $cliente;
    public $cliente_s;

    public $clave;
    public $clave_s;

    public $direccion;
    public $divisa;
    public $fabricante;
    public $familia;
    public $forma_pago;
    public $grupo;
    public $impuesto;
    public $nuevocli_setup;
    public $pais;
    public $results;
    public $serie;
    public $tipo;

    public $CFDI;
    public $metodo;

    public function __construct() {
        parent::__construct(__CLASS__, 'Nueva venta...', 'ventas', FALSE, FALSE, TRUE);
    }

    protected function private_core() {
        parent::private_core();

        $this->agencia = new agencia_transporte();
        $this->cliente = new cliente();
        $this->cliente_s = FALSE;

        $this->clave = new claveProdServ();
        $this->clave_s = FALSE;


        $this->direccion = FALSE;
        $this->fabricante = new fabricante();
        $this->familia = new familia();
        $this->impuesto = new impuesto();
        $this->results = array();
        $this->grupo = new grupo_clientes();
        $this->pais = new pais();

        $this->CFDI = new usoCFDI();
        $this->metodo = new metodoPago();

        /// cargamos la configuración
        $fsvar = new fs_var();
        $this->nuevocli_setup = $fsvar->array_get(
                array(
            'nuevocli_cifnif_req' => 0,
            'nuevocli_direccion' => 0,
            'nuevocli_direccion_req' => 0,
            'nuevocli_codpostal' => 0,
            'nuevocli_codpostal_req' => 0,
            'nuevocli_pais' => 0,
            'nuevocli_pais_req' => 0,
            'nuevocli_provincia' => 0,
            'nuevocli_provincia_req' => 0,
            'nuevocli_ciudad' => 0,
            'nuevocli_ciudad_req' => 0,
            'nuevocli_telefono1' => 0,
            'nuevocli_telefono1_req' => 0,
            'nuevocli_telefono2' => 0,
            'nuevocli_telefono2_req' => 0,
            'nuevocli_email' => 0,
            'nuevocli_email_req' => 0,
            'nuevocli_codgrupo' => '',
                ), FALSE
        );

        if (isset($_REQUEST['tipo'])) {
            $this->tipo = $_REQUEST['tipo'];
        } else {
            foreach ($this->tipos_a_guardar() as $t) {
                $this->tipo = $t['tipo'];
                break;
            }
        }

        if (isset($_REQUEST['buscar_cliente'])) {
            $this->fbase_buscar_cliente($_REQUEST['buscar_cliente']);
        } else if (isset($_REQUEST['datoscliente'])) {
            $this->datos_cliente();
        } else if (isset($_REQUEST['new_articulo'])) {
            $this->new_articulo();
        } else if ($this->query != '') {
            $this->new_search();
        } else if (isset($_POST['referencia4precios'])) {
            $this->get_precios_articulo();
        } else if (isset($_POST['referencia4combi'])) {
            $this->get_combinaciones_articulo();
        } else if (isset($_POST['cliente'])) {
            $this->cliente_s = $this->cliente->get($_POST['cliente']);

            /**
             * Nuevo cliente
             */
            if (isset($_POST['nuevo_cliente'])) {
                if ($_POST['nuevo_cliente'] != '') {
                    $this->cliente_s = FALSE;
                    if ($_POST['nuevo_cifnif'] != '') {
                        $this->cliente_s = $this->cliente->get_by_cifnif($_POST['nuevo_cifnif']);
                        if ($this->cliente_s) {
                            $this->new_advice('Ya existe un cliente con ese ' . FS_CIFNIF . '. Se ha seleccionado.');
                        }
                    }

                    if (!$this->cliente_s) {
                        $this->cliente_s = new cliente();
                        $this->cliente_s->codcliente = $this->cliente_s->get_new_codigo();
                        $this->cliente_s->nombre = $this->cliente_s->razonsocial = $_POST['nuevo_cliente'];
                        $this->cliente_s->tipoidfiscal = $_POST['nuevo_tipoidfiscal'];
                        $this->cliente_s->cifnif = $_POST['nuevo_cifnif'];
                        $this->cliente_s->personafisica = isset($_POST['personafisica']);

                        $this->cliente_s->id_UsoCFDI = $_POST['id_UsoCFDI'];
                        $this->cliente_s->numregtrib = $_POST['numregtrib'];
                        $this->cliente_s->pais = $_POST['pais'];

                        if (isset($_POST['nuevo_email'])) {
                            $this->cliente_s->email = $_POST['nuevo_email'];
                        }

                        if (isset($_POST['codgrupo'])) {
                            if ($_POST['codgrupo'] != '') {
                                $this->cliente_s->codgrupo = $_POST['codgrupo'];
                            }
                        }

                        if (isset($_POST['nuevo_telefono1'])) {
                            $this->cliente_s->telefono1 = $_POST['nuevo_telefono1'];
                        }

                        if (isset($_POST['nuevo_telefono2'])) {
                            $this->cliente_s->telefono2 = $_POST['nuevo_telefono2'];
                        }

                        if ($this->cliente_s->save()) {
                            if ($this->empresa->contintegrada) {
                                /// forzamos crear la subcuenta
                                $this->cliente_s->get_subcuenta($this->empresa->codejercicio);
                            }

                            $dircliente = new direccion_cliente();
                            $dircliente->codcliente = $this->cliente_s->codcliente;
                            $dircliente->codpais = $this->empresa->codpais;
                            $dircliente->provincia = $this->empresa->provincia;
                            $dircliente->ciudad = $this->empresa->ciudad;

                            if (isset($_POST['nuevo_pais'])) {
                                $dircliente->codpais = $_POST['nuevo_pais'];
                            }

                            if (isset($_POST['nuevo_provincia'])) {
                                $dircliente->provincia = $_POST['nuevo_provincia'];
                            }

                            if (isset($_POST['nuevo_ciudad'])) {
                                $dircliente->ciudad = $_POST['nuevo_ciudad'];
                            }

                            if (isset($_POST['nuevo_codpostal'])) {
                                $dircliente->codpostal = $_POST['nuevo_codpostal'];
                            }

                            if (isset($_POST['nuevo_direccion'])) {
                                $dircliente->direccion = $_POST['nuevo_direccion'];
                            }

                            if ($dircliente->save()) {
                                $this->new_message('Cliente agregado correctamente.');
                            }
                        } else
                            $this->new_error_msg("¡Imposible guardar la dirección del cliente!");
                    }
                }
            }

            if ($this->cliente_s) {
                foreach ($this->cliente_s->get_direcciones() as $dir) {
                    if ($dir->domfacturacion) {
                        $this->direccion = $dir;
                        break;
                    }
                }
            }

            if (isset($_POST['codagente'])) {
                $agente = new agente();
                $this->agente = $agente->get($_POST['codagente']);
            } else
                $this->agente = $this->user->get_agente();

            $this->almacen = new almacen();
            $this->serie = new serie();
            $this->forma_pago = new forma_pago();
            $this->divisa = new divisa();

            if (isset($_POST['tipo'])) {
                if ($_POST['tipo'] == 'factura') {
                    $this->nueva_factura_cliente();
                } else if ($_POST['tipo'] == 'albaran') {
                    $this->nuevo_albaran_cliente();
                } else if ($_POST['tipo'] == 'pedido' AND class_exists('pedido_cliente')) {
                    $this->nuevo_pedido_cliente();
                } else if ($_POST['tipo'] == 'presupuesto' AND class_exists('presupuesto_cliente')) {
                    $this->nuevo_presupuesto_cliente();
                }

                /// si el cliente no tiene cifnif nos guardamos el que indique
                if ($this->cliente_s->cifnif == '') {
                    $this->cliente_s->cifnif = $_POST['cifnif'];
                    $this->cliente_s->save();
                }

                /// ¿Guardamos la dirección como nueva?
                /*if ($_POST['coddir'] == 'nueva') {
                    $this->direccion = new direccion_cliente();
                    $this->direccion->codcliente = $this->cliente_s->codcliente;
                    $this->direccion->codpais = $_POST['codpais'];
                    $this->direccion->provincia = $_POST['provincia'];
                    $this->direccion->ciudad = $_POST['ciudad'];
                    $this->direccion->codpostal = $_POST['codpostal'];
                    $this->direccion->direccion = $_POST['direccion'];
                    $this->direccion->apartado = $_POST['apartado'];
                    $this->direccion->save();
                } else if ($_POST['envio_coddir'] == 'nueva') {
                    $this->direccion = new direccion_cliente();
                    $this->direccion->codcliente = $this->cliente_s->codcliente;
                    $this->direccion->codpais = $_POST['envio_codpais'];
                    $this->direccion->provincia = $_POST['envio_provincia'];
                    $this->direccion->ciudad = $_POST['envio_ciudad'];
                    $this->direccion->codpostal = $_POST['envio_codpostal'];
                    $this->direccion->direccion = $_POST['envio_direccion'];
                    $this->direccion->apartado = $_POST['envio_apartado'];
                    $this->direccion->domfacturacion = FALSE;
                    $this->direccion->domenvio = TRUE;
                    $this->direccion->save();
                }*/
            }
        }
    }

    /**
     * Devuelve los tipos de documentos a guardar,
     * así para añadir tipos no hay que tocar la vista.
     * @return type
     */
    public function tipos_a_guardar() {
        $tipos = array();

        if ($this->user->have_access_to('ventas_presupuesto') AND class_exists('presupuesto_cliente')) {
            $tipos[] = array('tipo' => 'presupuesto', 'nombre' => ucfirst(FS_PRESUPUESTO) . ' para cliente');
        }

        if ($this->user->have_access_to('ventas_pedido') AND class_exists('pedido_cliente')) {
            $tipos[] = array('tipo' => 'pedido', 'nombre' => ucfirst(FS_PEDIDO) . ' de cliente');
        }

        if ($this->user->have_access_to('ventas_albaran')) {
            $tipos[] = array('tipo' => 'albaran', 'nombre' => ucfirst(FS_ALBARAN) . ' de cliente');
        }

        if ($this->user->have_access_to('ventas_factura')) {
            $tipos[] = array('tipo' => 'factura', 'nombre' => 'Factura de cliente');
        }

        return $tipos;
    }

    public function url() {
        return 'index.php?page=' . __CLASS__ . '&tipo=' . $this->tipo;
    }

    private function datos_cliente() {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;

        header('Content-Type: application/json');
        echo json_encode($this->cliente->get($_REQUEST['datoscliente']));
    }

    private function new_articulo() {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;

        $art0 = new articulo();
        if ($_REQUEST['referencia'] != '') {
            $art0->referencia = $_REQUEST['referencia'];
        } else {
            $art0->referencia = $art0->get_new_referencia();
        }

        if ($art0->exists()) {
            $this->results[] = $art0->get($art0->referencia);
        } else {
            $art0->descripcion = $_REQUEST['descripcion'];
            $art0->codbarras = $_REQUEST['codbarras'];
            $art0->set_impuesto($_REQUEST['codimpuesto']);
            $art0->set_pvp(floatval($_REQUEST['pvp']));

            $art0->secompra = isset($_POST['secompra']);
            $art0->sevende = isset($_POST['sevende']);
            $art0->nostock = isset($_POST['nostock']);
            $art0->publico = isset($_POST['publico']);

            if ($_REQUEST['codfamilia'] != '') {
                $art0->codfamilia = $_REQUEST['codfamilia'];
            }

            if ($_REQUEST['codfabricante'] != '') {
                $art0->codfabricante = $_REQUEST['codfabricante'];
            }

            if ($art0->save()) {
                $this->results[] = $art0;
            }
        }

        header('Content-Type: application/json');
        echo json_encode($this->results);
    }

    private function new_search() {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;

        $articulo = new articulo();
        $codfamilia = '';
        if (isset($_REQUEST['codfamilia'])) {
            $codfamilia = $_REQUEST['codfamilia'];
        }
        $codfabricante = '';
        if (isset($_REQUEST['codfabricante'])) {
            $codfabricante = $_REQUEST['codfabricante'];
        }
        $con_stock = isset($_REQUEST['con_stock']);
        $this->results = $articulo->search($this->query, 0, $codfamilia, $con_stock, $codfabricante);

        /// añadimos la busqueda, el descuento, la cantidad, etc...
        $stock = new stock();
        foreach ($this->results as $i => $value) {
            $this->results[$i]->query = $this->query;
            $this->results[$i]->dtopor = 0;
            $this->results[$i]->cantidad = 1;
            $this->results[$i]->coddivisa = $this->empresa->coddivisa;

            /// añadimos el stock del almacén y el general
            $this->results[$i]->stockalm = $this->results[$i]->stockfis;
            if ($this->multi_almacen AND isset($_REQUEST['codalmacen'])) {
                $this->results[$i]->stockalm = $stock->total_from_articulo($this->results[$i]->referencia, $_REQUEST['codalmacen']);
            }
        }

        /// ejecutamos las funciones de las extensiones
        foreach ($this->extensions as $ext) {
            if ($ext->type == 'function' AND $ext->params == 'new_search') {
                $name = $ext->text;
                $name($this->db, $this->results);
            }
        }

        /// buscamos el grupo de clientes y la tarifa
        if (isset($_REQUEST['codcliente'])) {
            $cliente = $this->cliente->get($_REQUEST['codcliente']);
            if ($cliente) {
                if ($cliente->codgrupo) {
                    $grupo0 = new grupo_clientes();
                    $tarifa0 = new tarifa();

                    $grupo = $grupo0->get($cliente->codgrupo);
                    if ($grupo) {
                        $tarifa = $tarifa0->get($grupo->codtarifa);
                        if ($tarifa) {
                            $tarifa->set_precios($this->results);
                        }
                    }
                }
            }
        }

        /// convertimos la divisa
        if (isset($_REQUEST['coddivisa'])) {
            if ($_REQUEST['coddivisa'] != $this->empresa->coddivisa) {
                foreach ($this->results as $i => $value) {
                    $this->results[$i]->coddivisa = $_REQUEST['coddivisa'];
                    $this->results[$i]->pvp = $this->divisa_convert($value->pvp, $this->empresa->coddivisa, $_REQUEST['coddivisa']);
                }
            }
        }

        header('Content-Type: application/json');
        echo json_encode($this->results);
    }
    /*private function new_search2() {
        /// desactivamos la plantilla HTML
        $this->template = FALSE;

        $clave = new claveProdServ();
        $id_ClaveProdServ = '';
        if (isset($_REQUEST['id_ClaveProdServ'])) {
            $id_ClaveProdServ = $_REQUEST['id_ClaveProdServ'];
        }
        $Descripcion = '';
        if (isset($_REQUEST['Descripcion'])) {
            $Descripcion = $_REQUEST['Descripcion'];
        }
        $c_ClaveProdServ = isset($_REQUEST['c_ClaveProdServ']);
        $this->results = $clave->search($this->query, 0, $id_ClaveProdServ, $c_ClaveProdServ, $Descripcion);

        /// ejecutamos las funciones de las extensiones
        foreach ($this->extensions as $ext) {
            if ($ext->type == 'function' AND $ext->params == 'new_search') {
                $name = $ext->text;
                $name($this->db, $this->results);
            }
        }

        header('Content-Type: application/json');
        echo json_encode($this->results);
    }*/

    private function get_precios_articulo() {
        /// cambiamos la plantilla HTML
        $this->template = 'ajax/nueva_venta_precios';

        $articulo = new articulo();
        $this->articulo = $articulo->get($_POST['referencia4precios']);
    }

    private function get_combinaciones_articulo() {
        /// cambiamos la plantilla HTML
        $this->template = 'ajax/nueva_venta_combinaciones';

        $impuestos = $this->impuesto->all();

        $this->results = array();
        $comb1 = new articulo_combinacion();
        foreach ($comb1->all_from_ref($_POST['referencia4combi']) as $com) {
            if (isset($this->results[$com->codigo])) {
                $this->results[$com->codigo]['desc'] .= ', ' . $com->nombreatributo . ' - ' . $com->valor;
                $this->results[$com->codigo]['txt'] .= ', ' . $com->nombreatributo . ' - ' . $com->valor;
            } else {
                $iva = 0;
                foreach ($impuestos as $imp) {
                    if ($imp->codimpuesto == $_POST['codimpuesto']) {
                        $iva = $imp->iva;
                        break;
                    }
                }

                $this->results[$com->codigo] = array(
                    'ref' => $_POST['referencia4combi'],
                    'desc' => base64_decode($_POST['desc']) . "\n" . $com->nombreatributo . ' - ' . $com->valor,
                    'pvp' => floatval($_POST['pvp']) + $com->impactoprecio,
                    'dto' => floatval($_POST['dto']),
                    'codimpuesto' => $_POST['codimpuesto'],
                    'iva' => $iva,
                    'cantidad' => floatval($_POST['cantidad']),
                    'txt' => $com->nombreatributo . ' - ' . $com->valor,
                    'codigo' => $com->codigo,
                    'stockfis' => $com->stockfis,
                );
            }
        }
    }

    public function get_tarifas_articulo($ref) {
        $tarlist = array();
        $articulo = new articulo();
        $tarifa = new tarifa();

        foreach ($tarifa->all() as $tar) {
            $art = $articulo->get($ref);
            if ($art) {
                $art->dtopor = 0;
                $aux = array($art);
                $tar->set_precios($aux);
                $tarlist[] = $aux[0];
            }
        }

        return $tarlist;
    }

    private function nuevo_albaran_cliente() {
        $continuar = TRUE;

        $cliente = $this->cliente->get($_POST['cliente']);
        if (!$cliente) {
            $this->new_error_msg('Cliente no encontrado.');
            $continuar = FALSE;
        }

        $almacen = $this->almacen->get($_POST['almacen']);
        if ($almacen) {
            $this->save_codalmacen($_POST['almacen']);
        } else {
            $this->new_error_msg('Almacén no encontrado.');
            $continuar = FALSE;
        }

        $eje0 = new ejercicio();
        $ejercicio = $eje0->get_by_fecha($_POST['fecha'], FALSE);
        if (!$ejercicio) {
            $this->new_error_msg('Ejercicio no encontrado.');
            $continuar = FALSE;
        }

        $serie = $this->serie->get($_POST['serie']);
        if (!$serie) {
            $this->new_error_msg('Serie no encontrada.');
            $continuar = FALSE;
        }

        $forma_pago = $this->forma_pago->get($_POST['forma_pago']);
        if ($forma_pago) {
            $this->save_codpago($_POST['forma_pago']);
        } else {
            $this->new_error_msg('Forma de pago no encontrada.');
            $continuar = FALSE;
        }

        $divisa = $this->divisa->get($_POST['divisa']);
        if (!$divisa) {
            $this->new_error_msg('Divisa no encontrada.');
            $continuar = FALSE;
        }

        $art0 = new articulo();
        $albaran = new albaran_cliente();
        $stock0 = new stock();

        if ($this->duplicated_petition($_POST['petition_id'])) {
            $this->new_error_msg('Petición duplicada. Has hecho doble clic sobre el botón guardar
               y se han enviado dos peticiones. Mira en <a href="' . $albaran->url() . '">' . FS_ALBARANES . '</a>
               para ver si el ' . FS_ALBARAN . ' se ha guardado correctamente.');
            $continuar = FALSE;
        }

        if ($continuar) {
            $albaran->fecha = $_POST['fecha'];
            $albaran->hora = $_POST['hora'];
            $albaran->codalmacen = $almacen->codalmacen;
            $albaran->codejercicio = $ejercicio->codejercicio;
            $albaran->codserie = $serie->codserie;
            $albaran->codpago = $forma_pago->codpago;
            $albaran->coddivisa = $divisa->coddivisa;
            $albaran->tasaconv = $divisa->tasaconv;

            if ($_POST['tasaconv'] != '') {
                $albaran->tasaconv = floatval($_POST['tasaconv']);
            }

            $albaran->codagente = $this->agente->codagente;
            $albaran->numero2 = $_POST['numero2'];
            $albaran->observaciones = $_POST['observaciones'];
            $albaran->porcomision = $this->agente->porcomision;

            $albaran->codcliente = $cliente->codcliente;
            $albaran->cifnif = $_POST['cifnif'];
            $albaran->nombrecliente = $_POST['nombrecliente'];
            $albaran->codpais = $_POST['codpais'];
            $albaran->provincia = $_POST['provincia'];
            $albaran->ciudad = $_POST['ciudad'];
            $albaran->codpostal = $_POST['codpostal'];
            $albaran->direccion = $_POST['direccion'];
            $albaran->apartado = $_POST['apartado'];

            /// envío
            $albaran->envio_nombre = $_POST['envio_nombre'];
            $albaran->envio_apellidos = $_POST['envio_apellidos'];
            if ($_POST['envio_codtrans'] != '') {
                $albaran->envio_codtrans = $_POST['envio_codtrans'];
            }
            $albaran->envio_codigo = $_POST['envio_codigo'];
            $albaran->envio_codpais = $_POST['envio_codpais'];
            $albaran->envio_provincia = $_POST['envio_provincia'];
            $albaran->envio_ciudad = $_POST['envio_ciudad'];
            $albaran->envio_codpostal = $_POST['envio_codpostal'];
            $albaran->envio_direccion = $_POST['envio_direccion'];
            $albaran->envio_apartado = $_POST['envio_apartado'];

            if ($albaran->save()) {
                $trazabilidad = FALSE;

                $n = floatval($_POST['numlineas']);
                for ($i = 0; $i <= $n; $i++) {
                    if (isset($_POST['referencia_' . $i])) {
                        $linea = new linea_albaran_cliente();
                        $linea->idalbaran = $albaran->idalbaran;
                        $linea->descripcion = $_POST['desc_' . $i];

                        if (!$serie->siniva AND $cliente->regimeniva != 'Exento') {
                            $imp0 = $this->impuesto->get_by_iva($_POST['iva_' . $i]);
                            if ($imp0) {
                                $linea->codimpuesto = $imp0->codimpuesto;
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            } else {
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            }
                        }

                        $linea->irpf = floatval($_POST['irpf_' . $i]);
                        $linea->pvpunitario = floatval($_POST['pvp_' . $i]);
                        $linea->cantidad = floatval($_POST['cantidad_' . $i]);
                        $linea->dtopor = floatval($_POST['dto_' . $i]);
                        $linea->pvpsindto = ($linea->pvpunitario * $linea->cantidad);
                        $linea->pvptotal = floatval($_POST['neto_' . $i]);

                        $articulo = $art0->get($_POST['referencia_' . $i]);
                        if ($articulo) {
                            $linea->referencia = $articulo->referencia;
                            if ($articulo->trazabilidad) {
                                $trazabilidad = TRUE;
                            }

                            if ($_POST['codcombinacion_' . $i]) {
                                $linea->codcombinacion = $_POST['codcombinacion_' . $i];
                            }
                        }

                        if ($linea->save()) {
                            if ($articulo AND isset($_POST['stock'])) {
                                $stockfis = $articulo->stockfis;
                                if ($this->multi_almacen) {
                                    $stockfis = $stock0->total_from_articulo($articulo->referencia, $albaran->codalmacen);
                                }

                                if (!$articulo->controlstock AND $linea->cantidad > $stockfis) {
                                    $this->new_error_msg("No hay suficiente stock del artículo <b>" . $linea->referencia . '</b>.');
                                    $linea->delete();
                                    $continuar = FALSE;
                                } else {
                                    /// descontamos del stock
                                    $articulo->sum_stock($albaran->codalmacen, 0 - $linea->cantidad, FALSE, $linea->codcombinacion);
                                }
                            }

                            $albaran->neto += $linea->pvptotal;
                            $albaran->totaliva += ($linea->pvptotal * $linea->iva / 100);
                            $albaran->totalirpf += ($linea->pvptotal * $linea->irpf / 100);
                            $albaran->totalrecargo += ($linea->pvptotal * $linea->recargo / 100);

                            if ($linea->irpf > $albaran->irpf) {
                                $albaran->irpf = $linea->irpf;
                            }
                        } else {
                            $this->new_error_msg("¡Imposible guardar la linea con referencia: " . $linea->referencia);
                            $continuar = FALSE;
                        }
                    }
                }

                if ($continuar) {
                    /// redondeamos
                    $albaran->neto = round($albaran->neto, FS_NF0);
                    $albaran->totaliva = round($albaran->totaliva, FS_NF0);
                    $albaran->totalirpf = round($albaran->totalirpf, FS_NF0);
                    $albaran->totalrecargo = round($albaran->totalrecargo, FS_NF0);
                    $albaran->total = $albaran->neto + $albaran->totaliva - $albaran->totalirpf + $albaran->totalrecargo;

                    if (abs(floatval($_POST['atotal']) - $albaran->total) >= .02) {
                        $this->new_error_msg("El total difiere entre la vista y el controlador (" . $_POST['atotal'] .
                                " frente a " . $albaran->total . "). Debes informar del error.");
                        $albaran->delete();
                    } else if ($albaran->save()) {
                        $this->new_message("<a href='" . $albaran->url() . "'>" . ucfirst(FS_ALBARAN) . "</a> guardado correctamente.");
                        $this->new_change(ucfirst(FS_ALBARAN) . ' Cliente ' . $albaran->codigo, $albaran->url(), TRUE);

                        if ($trazabilidad) {
                            header('Location: index.php?page=ventas_trazabilidad&doc=albaran&id=' . $albaran->idalbaran);
                        } else if ($_POST['redir'] == 'TRUE') {
                            header('Location: ' . $albaran->url());
                        }
                    } else
                        $this->new_error_msg("¡Imposible actualizar el <a href='" . $albaran->url() . "'>" . FS_ALBARAN . "</a>!");
                }
                else {
                    /// actualizamos el stock
                    foreach ($albaran->get_lineas() as $linea) {
                        if ($linea->referencia) {
                            $articulo = $art0->get($linea->referencia);
                            if ($articulo) {
                                $articulo->sum_stock($albaran->codalmacen, $linea->cantidad, FALSE, $linea->codcombinacion);
                            }
                        }
                    }

                    if (!$albaran->delete()) {
                        $this->new_error_msg("¡Imposible eliminar el <a href='" . $albaran->url() . "'>" . FS_ALBARAN . "</a>!");
                    }
                }
            } else
                $this->new_error_msg("¡Imposible guardar el " . FS_ALBARAN . "!");
        }
    }

    private function nueva_factura_cliente() {
        $continuar = TRUE;

        $cliente = $this->cliente->get($_POST['cliente']);
        if (!$cliente) {
            $this->new_error_msg('Cliente no encontrado.');
            $continuar = FALSE;
        }

        $almacen = $this->almacen->get($_POST['almacen']);
        if ($almacen) {
            $this->save_codalmacen($_POST['almacen']);
        } else {
            $this->new_error_msg('Almacén no encontrado.');
            $continuar = FALSE;
        }

        $eje0 = new ejercicio();
        $ejercicio = $eje0->get_by_fecha($_POST['fecha']);
        if (!$ejercicio) {
            $this->new_error_msg('Ejercicio no encontrado o está cerrado.');
            $continuar = FALSE;
        }

        $serie = $this->serie->get($_POST['serie']);
        if (!$serie) {
            $this->new_error_msg('Serie no encontrada.');
            $continuar = FALSE;
        }

        $forma_pago = $this->forma_pago->get($_POST['forma_pago']);
        if ($forma_pago) {
            $this->save_codpago($_POST['forma_pago']);
        } else {
            $this->new_error_msg('Forma de pago no encontrada.');
            $continuar = FALSE;
        }

        $divisa = $this->divisa->get($_POST['divisa']);
        if (!$divisa) {
            $this->new_error_msg('Divisa no encontrada.');
            $continuar = FALSE;
        }

        $art0 = new articulo();
        $factura = new factura_cliente();
        $stock0 = new stock();

        if ($this->duplicated_petition($_POST['petition_id'])) {
            $this->new_error_msg('Petición duplicada. Has hecho doble clic sobre el botón guardar
               y se han enviado dos peticiones. Mira en <a href="' . $factura->url() . '">Facturas</a>
               para ver si la factura se ha guardado correctamente.');
            $continuar = FALSE;
        }

        if ($continuar) {
            $factura->codejercicio = $ejercicio->codejercicio;
            $factura->codserie = $serie->codserie;
            $factura->set_fecha_hora($_POST['fecha'], $_POST['hora']);

            $factura->codalmacen = $almacen->codalmacen;
            $factura->codpago = $forma_pago->codpago;
            $factura->coddivisa = $divisa->coddivisa;
            $factura->tasaconv = $divisa->tasaconv;

            if ($_POST['tasaconv'] != '') {
                $factura->tasaconv = floatval($_POST['tasaconv']);
            }

            $factura->codagente = $this->agente->codagente;
            $factura->observaciones = $_POST['observaciones'];
            $factura->id_MetodoPago = $_POST['metodo'];
            $factura->confirmacion = $_POST['confirmacion'];
            
            //$factura->numero2 = $_POST['numero2'];
            $factura->porcomision = $this->agente->porcomision;

            if ($forma_pago->genrecibos == 'Pagados') {
                $factura->pagada = TRUE;
            }

            $factura->vencimiento = $forma_pago->calcular_vencimiento($factura->fecha, $cliente->diaspago);

            $factura->codcliente = $cliente->codcliente;
            $factura->cifnif = $_POST['cifnif'];
            $factura->nombrecliente = $_POST['nombrecliente'];
            $factura->codpais = $_POST['codpais'];
            $factura->provincia = $_POST['provincia'];
            $factura->ciudad = $_POST['ciudad'];
            //$factura->codpostal = $_POST['codpostal'];
            $factura->folio = $_POST['folio'];
            //$factura->direccion = $_POST['direccion'];
            //$factura->apartado = $_POST['apartado'];

            /// envío
            /*$factura->envio_nombre = $_POST['envio_nombre'];
            $factura->envio_apellidos = $_POST['envio_apellidos'];
            if ($_POST['envio_codtrans'] != '') {
                $factura->envio_codtrans = $_POST['envio_codtrans'];
            }
            $factura->envio_codigo = $_POST['envio_codigo'];
            $factura->envio_codpais = $_POST['envio_codpais'];
            $factura->envio_provincia = $_POST['envio_provincia'];
            $factura->envio_ciudad = $_POST['envio_ciudad'];
            $factura->envio_codpostal = $_POST['envio_codpostal'];
            $factura->envio_direccion = $_POST['envio_direccion'];
            $factura->envio_apartado = $_POST['envio_apartado'];*/

            $regularizacion = new regularizacion_iva();
            if ($regularizacion->get_fecha_inside($factura->fecha)) {
                $this->new_error_msg("El " . FS_IVA . " de ese periodo ya ha sido regularizado."
                        . " No se pueden añadir más facturas en esa fecha.");
            } else if ($factura->save()) {
                $trazabilidad = FALSE;

                $n = floatval($_POST['numlineas']);
                for ($i = 0; $i <= $n; $i++) {
                    if (isset($_POST['referencia_' . $i])) {
                        $linea = new linea_factura_cliente();
                        $linea->idfactura = $factura->idfactura;

                        $linea->referencia = $_POST['referencia_' . $i];
                        $linea->descripcion = $_POST['desc_' . $i];
                        $linea->claveU = $_POST['claveU_' . $i];
                        $linea->unidad = $_POST['unidad_' . $i];
                        $linea->identificacion = $_POST['identificacion_' . $i];

                        if (!$serie->siniva AND $cliente->regimeniva != 'Exento') {
                            $imp0 = $this->impuesto->get_by_iva($_POST['iva_' . $i]);
                            if ($imp0) {
                                $linea->codimpuesto = $imp0->codimpuesto;
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            } else {
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            }
                        }

                        $linea->irpf = floatval($_POST['irpf_' . $i]);
                        $linea->pvpunitario = floatval($_POST['pvp_' . $i]);
                        $linea->cantidad = floatval($_POST['cantidad_' . $i]);
                        $linea->dtopor = floatval($_POST['dto_' . $i]);
                        $linea->pvpsindto = ($linea->pvpunitario * $linea->cantidad);
                        $linea->pvptotal = floatval($_POST['neto_' . $i]);

                        $articulo = $art0->get($_POST['referencia_' . $i]);
                        if ($articulo) {
                            $linea->referencia = $articulo->referencia;
                            if ($articulo->trazabilidad) {
                                $trazabilidad = TRUE;
                            }

                            if ($_POST['codcombinacion_' . $i]) {
                                $linea->codcombinacion = $_POST['codcombinacion_' . $i];
                            }
                        }

                        if ($linea->save()) {
                            if ($articulo AND isset($_POST['stock'])) {
                                $stockfis = $articulo->stockfis;
                                if ($this->multi_almacen) {
                                    $stockfis = $stock0->total_from_articulo($articulo->referencia, $factura->codalmacen);
                                }

                                if (!$articulo->controlstock AND $linea->cantidad > $stockfis) {
                                    $this->new_error_msg("No hay suficiente stock del artículo <b>" . $linea->referencia . '</b>.');
                                    $linea->delete();
                                    $continuar = FALSE;
                                } else {
                                    /// descontamos del stock
                                    $articulo->sum_stock($factura->codalmacen, 0 - $linea->cantidad, FALSE, $linea->codcombinacion);
                                }
                            }

                            $factura->neto += $linea->pvptotal;
                            $factura->totaliva += ($linea->pvptotal * $linea->iva / 100);
                            $factura->totalirpf += ($linea->pvptotal * $linea->irpf / 100);
                            $factura->totalrecargo += ($linea->pvptotal * $linea->recargo / 100);

                            if ($linea->irpf > $factura->irpf) {
                                $factura->irpf = $linea->irpf;
                            }
                        } else {
                            $this->new_error_msg("¡Imposible guardar la linea con referencia: " . $linea->referencia);
                            $continuar = FALSE;
                        }
                    }
                }

                if ($continuar) {
                    /// redondeamos
                    $factura->neto = round($factura->neto, FS_NF0);
                    $factura->totaliva = round($factura->totaliva, FS_NF0);
                    $factura->totalirpf = round($factura->totalirpf, FS_NF0);
                    $factura->totalrecargo = round($factura->totalrecargo, FS_NF0);
                    $factura->total = $factura->neto + $factura->totaliva - $factura->totalirpf + $factura->totalrecargo;

                    if (abs(floatval($_POST['atotal']) - $factura->total) >= .02) {
                        $this->new_error_msg("El total difiere entre la vista y el controlador (" . $_POST['atotal'] .
                                " frente a " . $factura->total . "). Debes informar del error.");
                        $factura->delete();
                    } else if ($factura->save()) {
                        $this->generar_asiento($factura);
                        $this->new_message("<a href='" . $factura->url() . "'>Factura</a> guardada correctamente.");
                        $this->new_change('Factura Cliente ' . $factura->codigo, $factura->url(), TRUE);

                        if ($trazabilidad) {
                            header('Location: index.php?page=ventas_trazabilidad&doc=factura&id=' . $factura->idfactura);
                        } else if ($_POST['redir'] == 'TRUE') {
                            header('Location: ' . $factura->url());
                        }
                    } else
                        $this->new_error_msg("¡Imposible actualizar la <a href='" . $factura->url() . "'>Factura</a>!");
                }
                else {
                    /// actualizamos el stock
                    foreach ($factura->get_lineas() as $linea) {
                        if ($linea->referencia) {
                            $articulo = $art0->get($linea->referencia);
                            if ($articulo) {
                                $articulo->sum_stock($factura->codalmacen, $linea->cantidad, FALSE, $linea->codcombinacion);
                            }
                        }
                    }

                    if (!$factura->delete()) {
                        $this->new_error_msg("¡Imposible eliminar la <a href='" . $factura->url() . "'>Factura</a>!");
                    }
                }
            } else
                $this->new_error_msg("¡Imposible guardar la Factura!");
        }
    }

    /**
     * Genera el asiento para la factura, si procede
     * @param factura_cliente $factura
     */
    private function generar_asiento(&$factura) {
        if ($this->empresa->contintegrada) {
            $asiento_factura = new asiento_factura();
            $asiento_factura->generar_asiento_venta($factura);

            foreach ($asiento_factura->errors as $err) {
                $this->new_error_msg($err);
            }

            foreach ($asiento_factura->messages as $msg) {
                $this->new_message($msg);
            }
        } else {
            /// de todas formas forzamos la generación de las líneas de iva
            $factura->get_lineas_iva();
        }
    }

    private function nuevo_presupuesto_cliente() {
        $continuar = TRUE;

        $cliente = $this->cliente->get($_POST['cliente']);
        if (!$cliente) {
            $this->new_error_msg('Cliente no encontrado.');
            $continuar = FALSE;
        }

        $almacen = $this->almacen->get($_POST['almacen']);
        if ($almacen) {
            $this->save_codalmacen($_POST['almacen']);
        } else {
            $this->new_error_msg('Almacén no encontrado.');
            $continuar = FALSE;
        }

        $eje0 = new ejercicio();
        $ejercicio = $eje0->get_by_fecha($_POST['fecha'], FALSE);
        if (!$ejercicio) {
            $this->new_error_msg('Ejercicio no encontrado.');
            $continuar = FALSE;
        }

        $serie = $this->serie->get($_POST['serie']);
        if (!$serie) {
            $this->new_error_msg('Serie no encontrada.');
            $continuar = FALSE;
        }

        $forma_pago = $this->forma_pago->get($_POST['forma_pago']);
        if ($forma_pago) {
            $this->save_codpago($_POST['forma_pago']);
        } else {
            $this->new_error_msg('Forma de pago no encontrada.');
            $continuar = FALSE;
        }

        $divisa = $this->divisa->get($_POST['divisa']);
        if (!$divisa) {
            $this->new_error_msg('Divisa no encontrada.');
            $continuar = FALSE;
        }

        $presupuesto = new presupuesto_cliente();

        if ($this->duplicated_petition($_POST['petition_id'])) {
            $this->new_error_msg('Petición duplicada. Has hecho doble clic sobre el botón guardar
               y se han enviado dos peticiones. Mira en <a href="' . $presupuesto->url() . '">Presupuestos</a>
               para ver si el presupuesto se ha guardado correctamente.');
            $continuar = FALSE;
        }

        if ($continuar) {
            $presupuesto->fecha = $_POST['fecha'];
            $presupuesto->codalmacen = $almacen->codalmacen;
            $presupuesto->codejercicio = $ejercicio->codejercicio;
            $presupuesto->codserie = $serie->codserie;
            $presupuesto->codpago = $forma_pago->codpago;
            $presupuesto->coddivisa = $divisa->coddivisa;
            $presupuesto->tasaconv = $divisa->tasaconv;

            /// establecemos la fecha de finoferta
            $presupuesto->finoferta = date("Y-m-d", strtotime($_POST['fecha'] . " +1 month"));
            $fsvar = new fs_var();
            $dias = $fsvar->simple_get('presu_validez');
            if ($dias) {
                $presupuesto->finoferta = date("Y-m-d", strtotime($_POST['fecha'] . " +" . intval($dias) . " days"));
            }

            if ($_POST['tasaconv'] != '') {
                $presupuesto->tasaconv = floatval($_POST['tasaconv']);
            }

            $presupuesto->codagente = $this->agente->codagente;
            $presupuesto->observaciones = $_POST['observaciones'];
            $presupuesto->numero2 = $_POST['numero2'];
            $presupuesto->porcomision = $this->agente->porcomision;

            $presupuesto->codcliente = $cliente->codcliente;
            $presupuesto->cifnif = $_POST['cifnif'];
            $presupuesto->nombrecliente = $_POST['nombrecliente'];
            $presupuesto->codpais = $_POST['codpais'];
            $presupuesto->provincia = $_POST['provincia'];
            $presupuesto->ciudad = $_POST['ciudad'];
            $presupuesto->codpostal = $_POST['codpostal'];
            $presupuesto->direccion = $_POST['direccion'];
            $presupuesto->apartado = $_POST['apartado'];

            /// envío
            $presupuesto->envio_nombre = $_POST['envio_nombre'];
            $presupuesto->envio_apellidos = $_POST['envio_apellidos'];
            if ($_POST['envio_codtrans'] != '') {
                $presupuesto->envio_codtrans = $_POST['envio_codtrans'];
            }
            $presupuesto->envio_codigo = $_POST['envio_codigo'];
            $presupuesto->envio_codpais = $_POST['envio_codpais'];
            $presupuesto->envio_provincia = $_POST['envio_provincia'];
            $presupuesto->envio_ciudad = $_POST['envio_ciudad'];
            $presupuesto->envio_codpostal = $_POST['envio_codpostal'];
            $presupuesto->envio_direccion = $_POST['envio_direccion'];
            $presupuesto->envio_apartado = $_POST['envio_apartado'];

            if ($presupuesto->save()) {
                $art0 = new articulo();
                $n = floatval($_POST['numlineas']);
                for ($i = 0; $i <= $n; $i++) {
                    if (isset($_POST['referencia_' . $i])) {
                        $linea = new linea_presupuesto_cliente();
                        $linea->idpresupuesto = $presupuesto->idpresupuesto;
                        $linea->descripcion = $_POST['desc_' . $i];

                        if (!$serie->siniva AND $cliente->regimeniva != 'Exento') {
                            $imp0 = $this->impuesto->get_by_iva($_POST['iva_' . $i]);
                            if ($imp0) {
                                $linea->codimpuesto = $imp0->codimpuesto;
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            } else {
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            }
                        }

                        $linea->irpf = floatval($_POST['irpf_' . $i]);
                        $linea->pvpunitario = floatval($_POST['pvp_' . $i]);
                        $linea->cantidad = floatval($_POST['cantidad_' . $i]);
                        $linea->dtopor = floatval($_POST['dto_' . $i]);
                        $linea->pvpsindto = ($linea->pvpunitario * $linea->cantidad);
                        $linea->pvptotal = floatval($_POST['neto_' . $i]);

                        $articulo = $art0->get($_POST['referencia_' . $i]);
                        if ($articulo) {
                            $linea->referencia = $articulo->referencia;
                            if ($_POST['codcombinacion_' . $i]) {
                                $linea->codcombinacion = $_POST['codcombinacion_' . $i];
                            }
                        }

                        if ($linea->save()) {
                            $presupuesto->neto += $linea->pvptotal;
                            $presupuesto->totaliva += ($linea->pvptotal * $linea->iva / 100);
                            $presupuesto->totalirpf += ($linea->pvptotal * $linea->irpf / 100);
                            $presupuesto->totalrecargo += ($linea->pvptotal * $linea->recargo / 100);

                            if ($linea->irpf > $presupuesto->irpf) {
                                $presupuesto->irpf = $linea->irpf;
                            }
                        } else {
                            $this->new_error_msg("¡Imposible guardar la linea con referencia: " . $linea->referencia);
                            $continuar = FALSE;
                        }
                    }
                }

                if ($continuar) {
                    /// redondeamos
                    $presupuesto->neto = round($presupuesto->neto, FS_NF0);
                    $presupuesto->totaliva = round($presupuesto->totaliva, FS_NF0);
                    $presupuesto->totalirpf = round($presupuesto->totalirpf, FS_NF0);
                    $presupuesto->totalrecargo = round($presupuesto->totalrecargo, FS_NF0);
                    $presupuesto->total = $presupuesto->neto + $presupuesto->totaliva - $presupuesto->totalirpf + $presupuesto->totalrecargo;

                    if (abs(floatval($_POST['atotal']) - $presupuesto->total) >= .02) {
                        $this->new_error_msg("El total difiere entre el controlador y la vista (" .
                                $presupuesto->total . " frente a " . $_POST['atotal'] . "). Debes informar del error.");
                        $presupuesto->delete();
                    } else if ($presupuesto->save()) {
                        $this->new_message("<a href='" . $presupuesto->url() . "'>" . ucfirst(FS_PRESUPUESTO) . "</a> guardado correctamente.");
                        $this->new_change(ucfirst(FS_PRESUPUESTO) . ' a Cliente ' . $presupuesto->codigo, $presupuesto->url(), TRUE);

                        if ($_POST['redir'] == 'TRUE') {
                            header('Location: ' . $presupuesto->url());
                        }
                    } else
                        $this->new_error_msg("¡Imposible actualizar el <a href='" . $presupuesto->url() . "'>" . FS_PRESUPUESTO . "</a>!");
                }
                else if ($presupuesto->delete()) {
                    $this->new_message(ucfirst(FS_PRESUPUESTO) . " eliminado correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar el <a href='" . $presupuesto->url() . "'>" . FS_PRESUPUESTO . "</a>!");
            } else
                $this->new_error_msg("¡Imposible guardar el " . FS_PRESUPUESTO . "!");
        }
    }

    private function nuevo_pedido_cliente() {
        $continuar = TRUE;

        $cliente = $this->cliente->get($_POST['cliente']);
        if (!$cliente) {
            $this->new_error_msg('Cliente no encontrado.');
            $continuar = FALSE;
        }

        $almacen = $this->almacen->get($_POST['almacen']);
        if ($almacen) {
            $this->save_codalmacen($_POST['almacen']);
        } else {
            $this->new_error_msg('Almacén no encontrado.');
            $continuar = FALSE;
        }

        $eje0 = new ejercicio();
        $ejercicio = $eje0->get_by_fecha($_POST['fecha'], FALSE);
        if (!$ejercicio) {
            $this->new_error_msg('Ejercicio no encontrado.');
            $continuar = FALSE;
        }

        $serie = $this->serie->get($_POST['serie']);
        if (!$serie) {
            $this->new_error_msg('Serie no encontrada.');
            $continuar = FALSE;
        }

        $forma_pago = $this->forma_pago->get($_POST['forma_pago']);
        if ($forma_pago) {
            $this->save_codpago($_POST['forma_pago']);
        } else {
            $this->new_error_msg('Forma de pago no encontrada.');
            $continuar = FALSE;
        }

        $divisa = $this->divisa->get($_POST['divisa']);
        if (!$divisa) {
            $this->new_error_msg('Divisa no encontrada.');
            $continuar = FALSE;
        }

        $pedido = new pedido_cliente();

        if ($this->duplicated_petition($_POST['petition_id'])) {
            $this->new_error_msg('Petición duplicada. Has hecho doble clic sobre el botón guardar
               y se han enviado dos peticiones. Mira en <a href="' . $pedido->url() . '">Pedidos</a>
               para ver si el pedido se ha guardado correctamente.');
            $continuar = FALSE;
        }

        if ($continuar) {
            $pedido->fecha = $_POST['fecha'];
            $pedido->codalmacen = $almacen->codalmacen;
            $pedido->codejercicio = $ejercicio->codejercicio;
            $pedido->codserie = $serie->codserie;
            $pedido->codpago = $forma_pago->codpago;
            $pedido->coddivisa = $divisa->coddivisa;
            $pedido->tasaconv = $divisa->tasaconv;

            if ($_POST['tasaconv'] != '') {
                $pedido->tasaconv = floatval($_POST['tasaconv']);
            }

            $pedido->codagente = $this->agente->codagente;
            $pedido->observaciones = $_POST['observaciones'];
            $pedido->numero2 = $_POST['numero2'];
            $pedido->porcomision = $this->agente->porcomision;

            $pedido->codcliente = $cliente->codcliente;
            $pedido->cifnif = $_POST['cifnif'];
            $pedido->nombrecliente = $_POST['nombrecliente'];
            $pedido->codpais = $_POST['codpais'];
            $pedido->provincia = $_POST['provincia'];
            $pedido->ciudad = $_POST['ciudad'];
            $pedido->codpostal = $_POST['codpostal'];
            $pedido->direccion = $_POST['direccion'];
            $pedido->apartado = $_POST['apartado'];

            /// envío
            $pedido->envio_nombre = $_POST['envio_nombre'];
            $pedido->envio_apellidos = $_POST['envio_apellidos'];
            if ($_POST['envio_codtrans'] != '') {
                $pedido->envio_codtrans = $_POST['envio_codtrans'];
            }
            $pedido->envio_codigo = $_POST['envio_codigo'];
            $pedido->envio_codpais = $_POST['envio_codpais'];
            $pedido->envio_provincia = $_POST['envio_provincia'];
            $pedido->envio_ciudad = $_POST['envio_ciudad'];
            $pedido->envio_codpostal = $_POST['envio_codpostal'];
            $pedido->envio_direccion = $_POST['envio_direccion'];
            $pedido->envio_apartado = $_POST['envio_apartado'];

            if ($pedido->save()) {
                $art0 = new articulo();
                $n = floatval($_POST['numlineas']);
                for ($i = 0; $i <= $n; $i++) {
                    if (isset($_POST['referencia_' . $i])) {
                        $linea = new linea_pedido_cliente();
                        $linea->idpedido = $pedido->idpedido;
                        $linea->descripcion = $_POST['desc_' . $i];

                        if (!$serie->siniva AND $cliente->regimeniva != 'Exento') {
                            $imp0 = $this->impuesto->get_by_iva($_POST['iva_' . $i]);
                            if ($imp0) {
                                $linea->codimpuesto = $imp0->codimpuesto;
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            } else {
                                $linea->iva = floatval($_POST['iva_' . $i]);
                                $linea->recargo = floatval($_POST['recargo_' . $i]);
                            }
                        }

                        $linea->irpf = floatval($_POST['irpf_' . $i]);
                        $linea->pvpunitario = floatval($_POST['pvp_' . $i]);
                        $linea->cantidad = floatval($_POST['cantidad_' . $i]);
                        $linea->dtopor = floatval($_POST['dto_' . $i]);
                        $linea->pvpsindto = ($linea->pvpunitario * $linea->cantidad);
                        $linea->pvptotal = floatval($_POST['neto_' . $i]);

                        $articulo = $art0->get($_POST['referencia_' . $i]);
                        if ($articulo) {
                            $linea->referencia = $articulo->referencia;
                            if ($_POST['codcombinacion_' . $i]) {
                                $linea->codcombinacion = $_POST['codcombinacion_' . $i];
                            }
                        }

                        if ($linea->save()) {
                            $pedido->neto += $linea->pvptotal;
                            $pedido->totaliva += ($linea->pvptotal * $linea->iva / 100);
                            $pedido->totalirpf += ($linea->pvptotal * $linea->irpf / 100);
                            $pedido->totalrecargo += ($linea->pvptotal * $linea->recargo / 100);

                            if ($linea->irpf > $pedido->irpf) {
                                $pedido->irpf = $linea->irpf;
                            }
                        } else {
                            $this->new_error_msg("¡Imposible guardar la linea con referencia: " . $linea->referencia);
                            $continuar = FALSE;
                        }
                    }
                }

                if ($continuar) {
                    /// redondeamos
                    $pedido->neto = round($pedido->neto, FS_NF0);
                    $pedido->totaliva = round($pedido->totaliva, FS_NF0);
                    $pedido->totalirpf = round($pedido->totalirpf, FS_NF0);
                    $pedido->totalrecargo = round($pedido->totalrecargo, FS_NF0);
                    $pedido->total = $pedido->neto + $pedido->totaliva - $pedido->totalirpf + $pedido->totalrecargo;

                    if (abs(floatval($_POST['atotal']) - $pedido->total) >= .02) {
                        $this->new_error_msg("El total difiere entre el controlador y la vista (" .
                                $pedido->total . " frente a " . $_POST['atotal'] . "). Debes informar del error.");
                        $pedido->delete();
                    } else if ($pedido->save()) {
                        $this->new_message("<a href='" . $pedido->url() . "'>" . ucfirst(FS_PEDIDO) . "</a> guardado correctamente.");
                        $this->new_change(ucfirst(FS_PEDIDO) . " a Cliente " . $pedido->codigo, $pedido->url(), TRUE);

                        if ($_POST['redir'] == 'TRUE') {
                            header('Location: ' . $pedido->url());
                        }
                    } else
                        $this->new_error_msg("¡Imposible actualizar el <a href='" . $pedido->url() . "'>" . FS_PEDIDO . "</a>!");
                }
                else if ($pedido->delete()) {
                    $this->new_message(ucfirst(FS_PEDIDO) . " eliminado correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar el <a href='" . $pedido->url() . "'>" . FS_PEDIDO . "</a>!");
            } else
                $this->new_error_msg("¡Imposible guardar el " . FS_PEDIDO . "!");
        }
    }

}
