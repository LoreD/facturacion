# documentos_facturas
Permite adjuntar archivos a facturas de compra o venta en FacturaScripts.

https://www.facturascripts.com