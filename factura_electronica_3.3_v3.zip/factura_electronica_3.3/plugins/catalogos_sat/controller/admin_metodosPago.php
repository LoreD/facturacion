<?php


require_model('metodoPago.php');

class admin_metodosPago extends fs_controller {

    public $metodoPago;

    public function __construct() {
        parent::__construct(__CLASS__, 'Metodos Pago', 'Cátalogos');
    }

    protected function private_core() {

        $this->metodoPago = new metodoPago();

        if (isset($_POST['id_MetodoPago'])) {
            $this->editar_metodoPago();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_metodoPago();
        }
    }

    private function editar_metodoPago() {
        $metodoPago = $this->metodoPago->get($_POST['id_MetodoPago']);
        if (!$metodoPago) {
            /// si no existe lo creamos
            $metodoPago = new metodoPago();
            $metodoPago->codmetodoPago = $_POST['id_MetodoPago'];
        }

        $metodoPago->c_MetodoPago = $_POST['c_MetodoPago'];
        $metodoPago->Descripcion = $_POST['Descripcion'];

        if ($metodoPago->save()) {
            $this->new_message("Método de pago " . $metodoPago->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el Método de pago!");
    }

    private function eliminar_metodoPago() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar metodoPagoes. Otro usuario podría necesitarlo.');
        } else {
            $metodoPago = $this->metodoPago->get($_GET['delete']);
            if ($metodoPago) {
                if ($metodoPago->delete()) {
                    $this->new_message("Método de pago " . $metodoPago->Descripcion . " eliminado correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la metodo de pago!");
            } else
                $this->new_error_msg("¡Método de pago no encontrado!");
        }
    }

}
