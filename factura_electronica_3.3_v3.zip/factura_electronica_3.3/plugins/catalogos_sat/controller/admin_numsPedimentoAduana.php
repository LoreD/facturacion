<?php


require_model('numPedimentoAduana.php');

class admin_numsPedimentoAduana extends fs_controller {

    public $pedimento;

    public $offset;
    public $order;
    public $limite;
    public $resultados;

    public function __construct() {
        parent::__construct(__CLASS__, 'Pedimento Aduana', 'Cátalogos');
    }

    protected function private_core() {

        $this->pedimento = new numPedimentoAduana();
        $this->offset = 0;
        $this->order = 'id_NumPedimentoAduana ASC';
        $this->limite = '20';
        $order2 = '';


        $this->mostrar = 'todo';
        if (isset($_GET['mostrar'])) {
            $this->mostrar = $_GET['mostrar'];
            setcookie('ventas_fac_mostrar', $this->mostrar, time() + FS_COOKIES_EXPIRE);
        } else if (isset($_COOKIE['ventas_fac_mostrar'])) {
            $this->mostrar = $_COOKIE['ventas_fac_mostrar'];
        }
        if (isset($_POST['id_NumPedimentoAduana'])) {
            $this->editar_pedimento();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_pedimento();
        }
        else if ($this->mostrar == 'buscar') {
            $this->buscar($order2);
        }
    }

    private function editar_pedimento() {
        $pedimento = $this->pedimento->get($_POST['id_NumPedimentoAduana']);
        if (!$pedimento) {
            /// si no existe lo creamos
            $pedimento = new pedimento();
            $pedimento->codaduana = $_POST['id_NumPedimentoAduana'];
        }

        $pedimento->c_Aduana = $_POST['c_Aduana'];
        $pedimento->Patente = $_POST['Patente'];
        $pedimento->Ejercicio = $_POST['Ejercicio'];
        $pedimento->Cantidad = $_POST['Cantidad'];

        if ($pedimento->save()) {
            $this->new_message(" " . $pedimento->Patente . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar!");
    }

    private function eliminar_pedimento() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar. Otro usuario podría necesitarlo.');
        } else {
            $pedimento = $this->pedimento->get($_GET['delete']);
            if ($pedimento) {
                if ($pedimento->delete()) {
                    $this->new_message(" " . $pedimento->Patente . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar!");
            } else
                $this->new_error_msg("¡no encontrado!");
        }
    }



     public function url($busqueda = FALSE) {
        if ($busqueda) {
            $url = parent::url() . "&mostrar=" . $this->mostrar
                . "&query=" . $this->query;
            return $url;
        } else {
            return parent::url();
        }
    }


    private function buscar($order2) {
        $this->resultados = array();
        $this->num_resultados = 0;
        $sql = " FROM c_numpedimentoaduana ";
        $where = 'WHERE ';

        if ($this->query) {
            $query = mb_strtolower($this->query, 'UTF8');
            $sql .= $where;
            if (is_numeric($query)) {
                $sql .= "(id_NumPedimentoAduana LIKE '%" . $query . "%' OR c_Aduana LIKE '%" . $query . "%' OR Patente LIKE '%" . $query . "%' OR Ejercicio LIKE '%" . $query . "%' OR Cantidad LIKE '%" . $query . "%')";
            } else {
                $sql .= "(lower(id_NumPedimentoAduana) LIKE '%" . $query . "%' OR lower(c_Aduana) LIKE '%" . $query . "%' OR lower(Patente) LIKE '%" . $query . "%' OR lower(Ejercicio) LIKE '%" . $query . "%' OR lower(Cantidad) LIKE '%" . $query . "%')";
            }
            $where = ' AND ';
        }


        $data = $this->db->select("SELECT COUNT(id_NumPedimentoAduana) as total" . $sql);
        if ($data) {
            $this->num_resultados = intval($data[0]['total']);

            $data2 = $this->db->select_limit("SELECT *" . $sql . " ORDER BY " . $this->order . $order2, $this->limite, $this->offset);
            if ($data2) {
                foreach ($data2 as $d) {
                    $this->resultados[] = new numPedimentoAduana($d);
                }
            }
        }
    }

}
