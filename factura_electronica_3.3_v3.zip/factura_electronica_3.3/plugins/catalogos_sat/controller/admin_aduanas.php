<?php


require_model('aduana.php');

class admin_aduanas extends fs_controller {

    public $aduana;

    public function __construct() {
        parent::__construct(__CLASS__, 'Aduana', 'Cátalogos');
    }

    protected function private_core() {

        $this->aduana = new aduana();

        if (isset($_POST['id_Aduana'])) {
            $this->editar_aduana();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_aduana();
        }
    }

    private function editar_aduana() {
        $aduana = $this->aduana->get($_POST['id_Aduana']);
        if (!$aduana) {
            /// si no existe lo creamos
            $aduana = new aduana();
            $aduana->codaduana = $_POST['id_Aduana'];
        }

        $aduana->c_Aduana = $_POST['c_Aduana'];
        $aduana->Descripcion = $_POST['Descripcion'];

        if ($aduana->save()) {
            $this->new_message("Aduana " . $aduana->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el Aduana!");
    }

    private function eliminar_aduana() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar aduanaes. Otro usuario podría necesitarlo.');
        } else {
            $aduana = $this->aduana->get($_GET['delete']);
            if ($aduana) {
                if ($aduana->delete()) {
                    $this->new_message("Aduana " . $aduana->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la Aduana!");
            } else
                $this->new_error_msg("¡Aduana no encontrado!");
        }
    }

}
