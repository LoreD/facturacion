<?php


require_model('tipoComprobante.php');

class admin_tiposComprobante extends fs_controller {

    public $tipoComprobante;

    public function __construct() {
        parent::__construct(__CLASS__, 'Tipo Comprobante', 'Cátalogos');
    }

    protected function private_core() {

        $this->tipoComprobante = new tipoComprobante();

        if (isset($_POST['id_TipoDeComprobante'])) {
            $this->editar_tipoComprobante();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_tipoComprobante();
        }
    }

    private function editar_tipoComprobante() {
        $tipoComprobante = $this->tipoComprobante->get($_POST['id_TipoDeComprobante']);
        if (!$tipoComprobante) {
            /// si no existe lo creamos
            $tipoComprobante = new tipoComprobante();
            $tipoComprobante->codtipoComprobante = $_POST['id_TipoDeComprobante'];
        }

        $tipoComprobante->c_TipoDeComprobante = $_POST['c_TipoDeComprobante'];
        $tipoComprobante->Descripcion = $_POST['Descripcion'];

        if ($tipoComprobante->save()) {
            $this->new_message("Tipo de comprobante " . $tipoComprobante->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el Tipo Comprobante!");
    }

    private function eliminar_tipoComprobante() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar tipoComprobantees. Otro usuario podría necesitarlo.');
        } else {
            $tipoComprobante = $this->tipoComprobante->get($_GET['delete']);
            if ($tipoComprobante) {
                if ($tipoComprobante->delete()) {
                    $this->new_message("Tipo de comprobante " . $tipoComprobante->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la Tipo Comprobante!");
            } else
                $this->new_error_msg("¡Tipo de comprobante no encontrado!");
        }
    }

}
