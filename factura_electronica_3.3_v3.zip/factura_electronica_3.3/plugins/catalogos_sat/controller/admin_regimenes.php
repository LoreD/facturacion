<?php


require_model('regimenFiscal.php');

class admin_regimenes extends fs_controller {

    public $regimenFiscal;

    public function __construct() {
        parent::__construct(__CLASS__, 'Regimen Fiscal', 'Cátalogos');
    }

    protected function private_core() {

        $this->regimenFiscal = new regimenFiscal();

        if (isset($_POST['id_RegimenFiscal'])) {
            $this->editar_regimenFiscal();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_regimenFiscal();
        }
    }

    private function editar_regimenFiscal() {
        $regimenFiscal = $this->regimenFiscal->get($_POST['id_RegimenFiscal']);
        if (!$regimenFiscal) {
            /// si no existe lo creamos
            $regimenFiscal = new regimenFiscal();
            $regimenFiscal->codregimenFiscal = $_POST['id_RegimenFiscal'];
        }

        $regimenFiscal->c_RegimenFiscal = $_POST['c_RegimenFiscal'];
        $regimenFiscal->Descripcion = $_POST['Descripcion'];

        if ($regimenFiscal->save()) {
            $this->new_message("regimenFiscal " . $regimenFiscal->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el regimenFiscal!");
    }

    private function eliminar_regimenFiscal() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar regimenFiscales. Otro usuario podría necesitarlo.');
        } else {
            $regimenFiscal = $this->regimenFiscal->get($_GET['delete']);
            if ($regimenFiscal) {
                if ($regimenFiscal->delete()) {
                    $this->new_message("regimenFiscal " . $regimenFiscal->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la regimenFiscal!");
            } else
                $this->new_error_msg("¡regimenFiscal no encontrado!");
        }
    }

}
