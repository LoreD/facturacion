<?php


require_model('patenteAduanal.php');

class admin_patentesAduanal extends fs_controller {

    public $patente;

    public $offset;
    public $order;
    public $limite;
    public $resultados;

    public function __construct() {
        parent::__construct(__CLASS__, 'Patente Aduanal', 'Cátalogos');
    }

    protected function private_core() {

        $this->patente = new patenteAduanal();

        $this->offset = 0;
        $this->order = 'id_PatenteAduanal ASC';
        $this->limite = '20';
        $order2 = '';


        $this->mostrar = 'todo';
        if (isset($_GET['mostrar'])) {
            $this->mostrar = $_GET['mostrar'];
            setcookie('ventas_fac_mostrar', $this->mostrar, time() + FS_COOKIES_EXPIRE);
        } else if (isset($_COOKIE['ventas_fac_mostrar'])) {
            $this->mostrar = $_COOKIE['ventas_fac_mostrar'];
        }


        if (isset($_POST['id_PatenteAduanal'])) {
            $this->editar_patente();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_patente();
        }
        

        else if ($this->mostrar == 'buscar') {
            $this->buscar($order2);
        }
    }

    private function editar_patente() {
        $patente = $this->patente->get($_POST['id_PatenteAduanal']);
        if (!$patente) {
            /// si no existe lo creamos
            $patente = new patenteAduanal();
            $patente->codpatente = $_POST['id_PatenteAduanal'];
        }

        $patente->c_PatenteAduanal = $_POST['c_PatenteAduanal'];

        if ($patente->save()) {
            $this->new_message("Patente " . $patente->c_PatenteAduanal . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el patente!");
    }

    private function eliminar_patente() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar aduanaes. Otro usuario podría necesitarlo.');
        } else {
            $patente = $this->patente->get($_GET['delete']);
            if ($patente) {
                if ($patente->delete()) {
                    $this->new_message("Patente " . $patente->c_PatenteAduanal . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la patente!");
            } else
                $this->new_error_msg("¡Patente no encontrado!");
        }
    }


     public function url($busqueda = FALSE) {
        if ($busqueda) {
            $url = parent::url() . "&mostrar=" . $this->mostrar
                . "&query=" . $this->query;
            return $url;
        } else {
            return parent::url();
        }
    }


    private function buscar($order2) {
        $this->resultados = array();
        $this->num_resultados = 0;
        $sql = " FROM c_patenteaduanal ";
        $where = 'WHERE ';

        if ($this->query) {
            $query = mb_strtolower($this->query, 'UTF8');
            $sql .= $where;
            if (is_numeric($query)) {
                $sql .= "(id_PatenteAduanal LIKE '%" . $query . "%' OR c_PatenteAduanal LIKE '%" . $query . "%')";
            } else {
                $sql .= "(lower(id_PatenteAduanal) LIKE '%" . $query . "%' OR lower(c_PatenteAduanal) LIKE '%" . $query . "%')";
            }
            $where = ' AND ';
        }


        $data = $this->db->select("SELECT COUNT(id_PatenteAduanal) as total" . $sql);
        if ($data) {
            $this->num_resultados = intval($data[0]['total']);

            $data2 = $this->db->select_limit("SELECT *" . $sql . " ORDER BY " . $this->order . $order2, $this->limite, $this->offset);
            if ($data2) {
                foreach ($data2 as $d) {
                    $this->resultados[] = new patenteAduanal($d);
                }
            }
        }
    }


}
