<?php
require_once 'plugins/facturacion_base/extras/fbase_controller.php';
require_model('claveProdServ.php');

class admin_clavesProd extends fbase_controller {

    public $claveProdServ;

    public $offset;
    public $order;
    public $limite;
    public $resultados;

    public function __construct() {
        parent::__construct(__CLASS__, 'Claves ProdServ', 'Cátalogos');
    }

    protected function private_core() {

        $this->claveProdServ = new claveProdServ();

        $this->offset = 0;
        $this->order = 'id_ClaveProdServ ASC';
        $this->limite = '20';
        $order2 = '';

        //agregar mostrar
        $this->mostrar = 'todo';
        if (isset($_GET['mostrar'])) {
            $this->mostrar = $_GET['mostrar'];
            setcookie('ventas_fac_mostrar', $this->mostrar, time() + FS_COOKIES_EXPIRE);
        } else if (isset($_COOKIE['ventas_fac_mostrar'])) {
            $this->mostrar = $_COOKIE['ventas_fac_mostrar'];
        }

        if (isset($_POST['id_ClaveProdServ'])) {
            $this->editar_clave();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_clave();
        }

        else if ($this->mostrar == 'buscar') {
            $this->buscar($order2);
        }
    }

    private function editar_clave() {
        $claveProdServ = $this->claveProdServ->get($_POST['id_ClaveProdServ']);
        if (!$claveProdServ) {
            /// si no existe lo creamos
            $claveProdServ = new claveProdServ();
            $claveProdServ->codclaveProdServ = $_POST['id_ClaveProdServ'];
        }

        $claveProdServ->c_ClaveProdServ = $_POST['c_ClaveProdServ'];
        $claveProdServ->Descripcion = $_POST['Descripcion'];

        if ($claveProdServ->save()) {
            $this->new_message("Clave " . $claveProdServ->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar la clave!");
    }

    private function eliminar_clave() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar claves. Otro usuario podría necesitarlo.');
        } else {
            $claveProdServ = $this->claveProdServ->get($_GET['delete']);
            if ($claveProdServ) {
                if ($claveProdServ->delete()) {
                    $this->new_message("Clave " . $claveProdServ->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la clave!");
            } else
                $this->new_error_msg("¡clave no encontrado!");
        }
    }



    public function url($busqueda = FALSE) {
        if ($busqueda) {
            $url = parent::url() . "&mostrar=" . $this->mostrar
                . "&query=" . $this->query;
            return $url;
        } else {
            return parent::url();
        }
    }


    private function buscar($order2) {
        $this->resultados = array();
        $this->num_resultados = 0;
        $sql = " FROM c_claveprodserv ";
        $where = 'WHERE ';

        if ($this->query) {
            $query = mb_strtolower($this->query, 'UTF8');
            $sql .= $where;
            if (is_numeric($query)) {
                $sql .= "(id_ClaveProdServ LIKE '%" . $query . "%' OR c_ClaveProdServ LIKE '%" . $query . "%' "
                        . "OR Descripcion LIKE '%" . $query . "%')";
            } else {
                $sql .= "(lower(id_ClaveProdServ) LIKE '%" . $query . "%' OR lower(c_ClaveProdServ) LIKE '%" . $query . "%' "
                        . "OR lower(Descripcion) LIKE '" . $query . "%')";
            }
            $where = ' AND ';
        }


        $data = $this->db->select("SELECT COUNT(id_ClaveProdServ) as total" . $sql);
        if ($data) {
            $this->num_resultados = intval($data[0]['total']);

            $data2 = $this->db->select_limit("SELECT *" . $sql . " ORDER BY " . $this->order . $order2, $this->limite, $this->offset);
            if ($data2) {
                foreach ($data2 as $d) {
                    $this->resultados[] = new claveProdServ($d);
                }
            }
        }
    }

}
