<?php


require_model('tipoRelacion.php');

class admin_tiposRelacion extends fs_controller {

    public $tipoRelacion;

    public function __construct() {
        parent::__construct(__CLASS__, 'Tipo Relacion', 'Cátalogos');
    }

    protected function private_core() {

        $this->tipoRelacion = new tipoRelacion();

        if (isset($_POST['id_TipoRelacion'])) {
            $this->editar_tipoRelacion();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_tipoRelacion();
        }
    }

    private function editar_tipoRelacion() {
        $tipoRelacion = $this->tipoRelacion->get($_POST['id_TipoRelacion']);
        if (!$tipoRelacion) {
            /// si no existe lo creamos
            $tipoRelacion = new tipoRelacion();
            $tipoRelacion->codtipoRelacion = $_POST['id_TipoRelacion'];
        }

        $tipoRelacion->c_TipoRelacion = $_POST['c_TipoRelacion'];
        $tipoRelacion->Descripcion = $_POST['Descripcion'];

        if ($tipoRelacion->save()) {
            $this->new_message("tipo " . $tipoRelacion->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el tipo!");
    }

    private function eliminar_tipoRelacion() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar tipo. Otro usuario podría necesitarlo.');
        } else {
            $tipoRelacion = $this->tipoRelacion->get($_GET['delete']);
            if ($tipoRelacion) {
                if ($tipoRelacion->delete()) {
                    $this->new_message("tipo " . $tipoRelacion->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar el tipo!");
            } else
                $this->new_error_msg("¡tipo no encontrado!");
        }
    }

}
