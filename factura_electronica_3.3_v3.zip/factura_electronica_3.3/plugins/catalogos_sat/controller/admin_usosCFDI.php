<?php


require_model('usoCFDI.php');

class admin_usosCFDI extends fs_controller {

    public $usoCFDI;

    public function __construct() {
        parent::__construct(__CLASS__, 'Uso CFDI', 'Cátalogos');
    }

    protected function private_core() {

        $this->usoCFDI = new usoCFDI();

        if (isset($_POST['id_UsoCFDI'])) {
            $this->editar_usoCFDI();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_usoCFDI();
        }
    }

    private function editar_usoCFDI() {
        $usoCFDI = $this->usoCFDI->get($_POST['id_UsoCFDI']);
        if (!$usoCFDI) {
            /// si no existe lo creamos
            $usoCFDI = new usoCFDI();
            $usoCFDI->codusoCFDI = $_POST['id_UsoCFDI'];
        }

        $usoCFDI->c_UsoCFDI = $_POST['c_UsoCFDI'];
        $usoCFDI->Descripcion = $_POST['Descripcion'];

        if ($usoCFDI->save()) {
            $this->new_message("usoCFDI " . $usoCFDI->Descripcion . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el usoCFDI!");
    }

    private function eliminar_usoCFDI() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar usoCFDIes. Otro usuario podría necesitarlo.');
        } else {
            $usoCFDI = $this->usoCFDI->get($_GET['delete']);
            if ($usoCFDI) {
                if ($usoCFDI->delete()) {
                    $this->new_message("usoCFDI " . $usoCFDI->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la usoCFDI!");
            } else
                $this->new_error_msg("¡usoCFDI no encontrado!");
        }
    }

}
