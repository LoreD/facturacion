<?php


require_model('tipoFactor.php');

class admin_tiposFactor extends fs_controller {

    public $tipoFactor;

    public function __construct() {
        parent::__construct(__CLASS__, 'Tipo Factor', 'Cátalogos');
    }

    protected function private_core() {

        $this->tipoFactor = new tipoFactor();

        if (isset($_POST['id_TipoFactor'])) {
            $this->editar_tipoFactor();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_tipoFactor();
        }
    }

    private function editar_tipoFactor() {
        $tipoFactor = $this->tipoFactor->get($_POST['id_TipoFactor']);
        if (!$tipoFactor) {
            /// si no existe lo creamos
            $tipoFactor = new tipoFactor();
            $tipoFactor->codtipoFactor = $_POST['id_TipoFactor'];
        }

        $tipoFactor->c_TipoFactor = $_POST['c_TipoFactor'];

        if ($tipoFactor->save()) {
            $this->new_message("tipoFactor " . $tipoFactor->c_TipoFactor . " guardado correctamente.");
        } else
            $this->new_error_msg("¡Imposible guardar el tipoFactor!");
    }

    private function eliminar_tipoFactor() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar tipoFactores. Otro usuario podría necesitarlo.');
        } else {
            $tipoFactor = $this->tipoFactor->get($_GET['delete']);
            if ($tipoFactor) {
                if ($tipoFactor->delete()) {
                    $this->new_message("tipoFactor " . $tipoFactor->c_TipoFactor . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la tipoFactor!");
            } else
                $this->new_error_msg("¡tipoFactor no encontrado!");
        }
    }

}
