<?php

require_model('claveUnidad.php');

class admin_clavesUnidad extends fs_controller {

    public $clave;
    public $mostrar;
    public $offset;
    public $order;
    public $limite;
    public $resultados;

    public function __construct() {
        parent::__construct(__CLASS__, 'Clave Unidad', 'Cátalogos');
    }

    protected function private_core() {

        $this->clave = new claveUnidad();
        $this->offset = 0;
        $this->order = 'id_ClaveUnidad ASC';
        $this->limite = '20';
        $order2 = '';

        //agregar mostrar
        $this->mostrar = 'todo';
        if (isset($_GET['mostrar'])) {
            $this->mostrar = $_GET['mostrar'];
            setcookie('ventas_fac_mostrar', $this->mostrar, time() + FS_COOKIES_EXPIRE);
        } else if (isset($_COOKIE['ventas_fac_mostrar'])) {
            $this->mostrar = $_COOKIE['ventas_fac_mostrar'];
        }


        if (isset($_POST['id_ClaveUnidad'])) {
            $this->editar_clave();
        } else if (isset($_GET['delete'])) {
            $this->eliminar_clave();
        }


        else if ($this->mostrar == 'buscar') {
                $this->buscar($order2);}
    }

    private function editar_clave() {
        $clave = $this->clave->get($_POST['id_ClaveUnidad']);
        if (!$clave) {
            /// si no existe lo creamos
            $clave = new clave();
            $clave->codclave = $_POST['id_ClaveUnidad'];
        }

        $clave->c_ClaveUnidad = $_POST['c_ClaveUnidad'];
        $clave->Nombre = $_POST['Nombre'];
        $clave->Descripcion = $_POST['Descripcion'];
        $clave->Simbolo = $_POST['Simbolo'];
        

        if ($clave->save()) {
            //$this->new_message("clave " . $clave->Nombre . " guardado correctamente.");
            header('Location: index.php?page=admin_clavesUnidad');
        } else
            $this->new_error_msg("¡Imposible guardar el clave!");
    }

    private function eliminar_clave() {
        if (FS_DEMO) {
            $this->new_error_msg('En el modo demo no puedes eliminar clavees. Otro usuario podría necesitarlo.');
        } else {
            $clave = $this->clave->get($_GET['delete']);
            if ($clave) {
                if ($clave->delete()) {
                    $this->new_message("clave " . $clave->Descripcion . " eliminada correctamente.");
                } else
                    $this->new_error_msg("¡Imposible eliminar la clave!");
            } else
                $this->new_error_msg("¡clave no encontrado!");
        }
    }

    public function url($busqueda = FALSE) {
        if ($busqueda) {
            $url = parent::url() . "&mostrar=" . $this->mostrar
                . "&query=" . $this->query;
            return $url;
        } else {
            return parent::url();
        }
    }


    private function buscar($order2) {
        $this->resultados = array();
        $this->num_resultados = 0;
        $sql = " FROM c_claveUnidad ";
        $where = 'WHERE ';

        if ($this->query) {
            $query = mb_strtolower($this->query, 'UTF8');
            $sql .= $where;
            if (is_numeric($query)) {
                $sql .= "(id_ClaveUnidad LIKE '%" . $query . "%' OR  c_ClaveUnidad LIKE '%" . $query . "%' "
                        . "OR Descripcion LIKE '%" . $query . "%' OR Simbolo LIKE '" . $query . "%' OR  Nombre LIKE '%" . $query . "%')";
            } else {
                $sql .= "(lower(id_ClaveUnidad) LIKE '%" . $query . "%' OR lower(c_ClaveUnidad) LIKE '%" . $query . "%' "
                        . "OR lower(Descripcion) LIKE '" . $query . "%' "
                        . "OR lower(Simbolo) LIKE '%" . str_replace(' ', '%', $query) . "%' OR  Nombre LIKE '%" . $query . "%')";
            }
            $where = ' AND ';
        }


        $data = $this->db->select("SELECT COUNT(id_ClaveUnidad) as total" . $sql);
        if ($data) {
            $this->num_resultados = intval($data[0]['total']);

            $data2 = $this->db->select_limit("SELECT *" . $sql . " ORDER BY " . $this->order . $order2, $this->limite, $this->offset);
            if ($data2) {
                foreach ($data2 as $d) {
                    $this->resultados[] = new claveUnidad($d);
                }
            }
        }
    }


}