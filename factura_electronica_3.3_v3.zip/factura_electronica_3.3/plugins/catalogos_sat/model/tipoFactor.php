<?php

class tipoFactor extends fs_model {

    public $id_TipoFactor;
    public $c_TipoFactor;
    

    public function __construct($tf = FALSE) {
        parent::__construct('c_tipofactor');
        if ($tf) {
            $this->id_TipoFactor = $tf['id_TipoFactor'];
            $this->c_TipoFactor = $tf['c_TipoFactor'];            
        } else {
            $this->id_TipoFactor = '';
            $this->c_TipoFactor = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_TipoFactor)) {
            return 'index.php?page=admin_tiposfactor';
        }

        return 'index.php?page=admin_tiposfactor#' . $this->id_TipoFactor;
    }

    
    public function is_default() {
        return ( $this->id_TipoFactor == $this->default_items->id_TipoFactor() );
    }

    
    public function get($cod) {
        $tipoFactor = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_TipoFactor = " . $this->var2str($cod) . ";");
        if ($tipoFactor) {
            return new \tipoFactor($tipoFactor[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $tipoFactor = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_TipoFactor = " . $this->var2str($cod) . ";");
        if ($tipoFactor) {
            return new \tipoFactor($tipoFactor[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_TipoFactor)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_TipoFactor = " . $this->var2str($this->id_TipoFactor) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_TipoFactor = trim($this->id_TipoFactor);
        $this->c_TipoFactor = $this->no_html($this->c_TipoFactor);

        if (strlen($this->c_TipoFactor) < 1) {
            $this->new_error_msg("Tipo no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_TipoFactor = " . $this->var2str($this->c_TipoFactor) .
                        "  WHERE id_TipoFactor = " . $this->var2str($this->id_TipoFactor) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_TipoFactor,c_TipoFactor) VALUES
                     (" . $this->var2str($this->id_TipoFactor) .
                        "," . $this->var2str($this->c_TipoFactor) .");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_TipoFactor = " . $this->var2str($this->id_TipoFactor) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_tipoFactor_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_tipoFactor_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_TipoFactor ASC;");
            if ($data) {
                foreach ($data as $tf) {
                    $listap[] = new \tipoFactor($tf);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_tipoFactor_all', $listap);
        }

        return $listap;
    }

}
