<?php

class regimenFiscal extends fs_model {

    public $id_RegimenFiscal;
    public $c_RegimenFiscal;
    public $Descripcion;

    public function __construct($r = FALSE) {
        parent::__construct('c_regimenfiscal');
        if ($r) {
            $this->id_RegimenFiscal = $r['id_RegimenFiscal'];
            $this->c_RegimenFiscal = $r['c_RegimenFiscal'];
            $this->Descripcion = $r['Descripcion'];
        } else {
            $this->id_RegimenFiscal = '';
            $this->c_RegimenFiscal = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_RegimenFiscal)) {
            return 'index.php?page=admin_regimenes';
        }

        return 'index.php?page=admin_regimenes#' . $this->id_RegimenFiscal;
    }



    /*public function is_default() {
        return ( $this->codregimen == $this->default_items->codregimen() );
    }*/

    
    public function is_default() {
        return ( $this->id_RegimenFiscal == $this->default_items->id_RegimenFiscal() );
    }

    
    public function get($cod) {
        $regimenFiscal = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_RegimenFiscal = " . $this->var2str($cod) . ";");
        if ($regimenFiscal) {
            return new \regimenFiscal($regimenFiscal[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $regimenFiscal = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_RegimenFiscal = " . $this->var2str($cod) . ";");
        if ($regimenFiscal) {
            return new \regimenFiscal($regimenFiscal[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_RegimenFiscal)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_RegimenFiscal = " . $this->var2str($this->id_RegimenFiscal) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_RegimenFiscal = trim($this->id_RegimenFiscal);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion no válida.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_RegimenFiscal = " . $this->var2str($this->c_RegimenFiscal) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_RegimenFiscal = " . $this->var2str($this->id_RegimenFiscal) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_RegimenFiscal,c_RegimenFiscal,Descripcion) VALUES
                     (" . $this->var2str($this->id_RegimenFiscal) .
                        "," . $this->var2str($this->c_RegimenFiscal) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_RegimenFiscal = " . $this->var2str($this->id_RegimenFiscal) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_regimenFiscal_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_regimenFiscal_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_RegimenFiscal ASC;");
            if ($data) {
                foreach ($data as $r) {
                    $listap[] = new \regimenFiscal($r);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_regimenFiscal_all', $listap);
        }

        return $listap;
    }

}
