<?php

class numPedimentoAduana extends fs_model {

    public $id_NumPedimentoAduana;
    public $c_Aduana;
    public $Patente;
    public $Ejercicio;
    public $Cantidad;

    public function __construct($np = FALSE) {
        parent::__construct('c_numpedimentoaduana');
        if ($np) {
            $this->id_NumPedimentoAduana = $np['id_NumPedimentoAduana'];
            $this->c_Aduana = $np['c_Aduana'];
            $this->Patente = $np['Patente'];
            $this->Ejercicio = $np['Ejercicio'];
            $this->Cantidad = $np['Cantidad'];
        } else {
            $this->id_NumPedimentoAduana = '';
            $this->c_Aduana = '';
            $this->Patente = '';
            $this->Ejercicio = '';
            $this->Cantidad = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_NumPedimentoAduana)) {
            return 'index.php?page=admin_numsPedimentoAduana';
        }

        return 'index.php?page=admin_numsPedimentoAduana#' . $this->id_NumPedimentoAduana;
    }

    
    public function is_default() {
        return ( $this->id_NumPedimentoAduana == $this->default_items->id_NumPedimentoAduana() );
    }

    
    public function get($cod) {
        $npedimento = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_NumPedimentoAduana = " . $this->var2str($cod) . ";");
        if ($npedimento) {
            return new \numPedimentoAduana($npedimento[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $npedimento = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_Aduana = " . $this->var2str($cod) . ";");
        if ($npedimento) {
            return new \numPedimentoAduana($npedimento[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_NumPedimentoAduana)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_NumPedimentoAduana = " . $this->var2str($this->id_NumPedimentoAduana) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_NumPedimentoAduana = trim($this->id_NumPedimentoAduana);
        $this->Patente = $this->no_html($this->Patente);

        if (strlen($this->Patente) < 1) {
            $this->new_error_msg("Patente del país no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_Aduana = " . $this->var2str($this->c_Aduana) .
                        ", Patente = " . $this->var2str($this->Patente) .
                        ", Ejercicio = " . $this->var2str($this->Ejercicio) .
                        ", Cantidad = " . $this->var2str($this->Cantidad) .
                        "  WHERE id_NumPedimentoAduana = " . $this->var2str($this->id_NumPedimentoAduana) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_NumPedimentoAduana,c_Aduana,Patente) VALUES
                     (" . $this->var2str($this->id_NumPedimentoAduana) .
                        "," . $this->var2str($this->c_Aduana) .
                        "," . $this->var2str($this->Patente) .
                        "," . $this->var2str($this->Ejercicio) .
                        "," . $this->var2str($this->Cantidad) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_NumPedimentoAduana = " . $this->var2str($this->id_NumPedimentoAduana) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_npedimento_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_npedimento_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_NumPedimentoAduana ASC LIMIT 20;");
            if ($data) {
                foreach ($data as $np) {
                    $listap[] = new \numPedimentoAduana($np);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_npedimento_all', $listap);
        }

        return $listap;
    }

}
