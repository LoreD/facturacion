<?php

class tipoRelacion extends fs_model {

    public $id_TipoRelacion;
    public $c_TipoRelacion;
    public $Descripcion;

    public function __construct($a = FALSE) {
        parent::__construct('c_tiporelacion');
        if ($a) {
            $this->id_TipoRelacion = $a['id_TipoRelacion'];
            $this->c_TipoRelacion = $a['c_TipoRelacion'];
            $this->Descripcion = $a['Descripcion'];
        } else {
            $this->id_TipoRelacion = '';
            $this->c_TipoRelacion = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_TipoRelacion)) {
            return 'index.php?page=admin_tiposRelacion';
        }

        return 'index.php?page=admin_tiposRelacion#' . $this->id_TipoRelacion;
    }

    
    public function is_default() {
        return ( $this->id_TipoRelacion == $this->default_items->id_TipoRelacion() );
    }

    
    public function get($cod) {
        $tipoRelacion = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_TipoRelacion = " . $this->var2str($cod) . ";");
        if ($tipoRelacion) {
            return new \tipoRelacion($tipoRelacion[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $tipoRelacion = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_TipoRelacion = " . $this->var2str($cod) . ";");
        if ($tipoRelacion) {
            return new \tipoRelacion($tipoRelacion[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_TipoRelacion)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_TipoRelacion = " . $this->var2str($this->id_TipoRelacion) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_TipoRelacion = trim($this->id_TipoRelacion);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion no válida.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_TipoRelacion = " . $this->var2str($this->c_TipoRelacion) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_TipoRelacion = " . $this->var2str($this->id_TipoRelacion) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_TipoRelacion,c_TipoRelacion,Descripcion) VALUES
                     (" . $this->var2str($this->id_TipoRelacion) .
                        "," . $this->var2str($this->c_TipoRelacion) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_TipoRelacion = " . $this->var2str($this->id_TipoRelacion) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_tipoRelacion_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_tipoRelacion_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_TipoRelacion ASC;");
            if ($data) {
                foreach ($data as $a) {
                    $listap[] = new \tipoRelacion($a);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_tipoRelacion_all', $listap);
        }

        return $listap;
    }

}
