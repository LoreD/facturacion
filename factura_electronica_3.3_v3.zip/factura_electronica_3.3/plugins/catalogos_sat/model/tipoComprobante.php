<?php

class tipoComprobante extends fs_model {

    public $id_TipoDeComprobante;
    public $c_TipoDeComprobante;
    public $Descripcion;

    public function __construct($tc = FALSE) {
        parent::__construct('c_tipodecomprobante');
        if ($tc) {
            $this->id_TipoDeComprobante = $tc['id_TipoDeComprobante'];
            $this->c_TipoDeComprobante = $tc['c_TipoDeComprobante'];
            $this->Descripcion = $tc['Descripcion'];
        } else {
            $this->id_TipoDeComprobante = '';
            $this->c_TipoDeComprobante = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_TipoDeComprobante)) {
            return 'index.php?page=admin_tiposComprobante';
        }

        return 'index.php?page=admin_tiposComprobante#' . $this->id_TipoDeComprobante;
    }

    
    public function is_default() {
        return ( $this->id_TipoDeComprobante == $this->default_items->id_TipoDeComprobante() );
    }

    
    public function get($cod) {
        $tipoComprobante = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_TipoDeComprobante = " . $this->var2str($cod) . ";");
        if ($tipoComprobante) {
            return new \tipoComprobante($tipoComprobante[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $tipoComprobante = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_TipoDeComprobante = " . $this->var2str($cod) . ";");
        if ($tipoComprobante) {
            return new \tipoComprobante($tipoComprobante[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_TipoDeComprobante)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_TipoDeComprobante = " . $this->var2str($this->id_TipoDeComprobante) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_TipoDeComprobante = trim($this->id_TipoDeComprobante);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion no válida.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_TipoDeComprobante = " . $this->var2str($this->c_TipoDeComprobante) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_TipoDeComprobante = " . $this->var2str($this->id_TipoDeComprobante) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_TipoDeComprobante,c_TipoDeComprobante,Descripcion) VALUES
                     (" . $this->var2str($this->id_TipoDeComprobante) .
                        "," . $this->var2str($this->c_TipoDeComprobante) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_TipoDeComprobante = " . $this->var2str($this->id_TipoDeComprobante) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_tipoComprobante_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_tipoComprobante_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_TipoDeComprobante ASC;");
            if ($data) {
                foreach ($data as $tc) {
                    $listap[] = new \tipoComprobante($tc);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_tipoComprobante_all', $listap);
        }

        return $listap;
    }

}
