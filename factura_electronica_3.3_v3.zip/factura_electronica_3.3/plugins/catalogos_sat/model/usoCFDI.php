<?php

class usoCFDI extends fs_model {

    public $id_UsoCFDI;
    public $c_UsoCFDI;
    public $Descripcion;

    public function __construct($uc = FALSE) {
        parent::__construct('c_usocfdi');
        if ($uc) {
            $this->id_UsoCFDI = $uc['id_UsoCFDI'];
            $this->c_UsoCFDI = $uc['c_UsoCFDI'];
            $this->Descripcion = $uc['Descripcion'];
        } else {
            $this->id_UsoCFDI = '';
            $this->c_UsoCFDI = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_UsoCFDI)) {
            return 'index.php?page=admin_usosCFDi';
        }

        return 'index.php?page=admin_usosCFDi#' . $this->id_UsoCFDI;
    }

    
    public function is_default() {
        return ( $this->id_UsoCFDI == $this->default_items->id_UsoCFDI() );
    }

    
    public function get($cod) {
        $uso = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_UsoCFDI = " . $this->var2str($cod) . ";");
        if ($uso) {
            return new \usoCFDI($uso[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $uso = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_UsoCFDI = " . $this->var2str($cod) . ";");
        if ($uso) {
            return new \usoCFDI($uso[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_UsoCFDI)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_UsoCFDI = " . $this->var2str($this->id_UsoCFDI) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_UsoCFDI = trim($this->id_UsoCFDI);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion del país no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_UsoCFDI = " . $this->var2str($this->c_UsoCFDI) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_UsoCFDI = " . $this->var2str($this->id_UsoCFDI) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_UsoCFDI,c_UsoCFDI,Descripcion) VALUES
                     (" . $this->var2str($this->id_UsoCFDI) .
                        "," . $this->var2str($this->c_UsoCFDI) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_UsoCFDI = " . $this->var2str($this->id_UsoCFDI) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_usoCFDI_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_usoCFDI_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_UsoCFDI ASC;");
            if ($data) {
                foreach ($data as $uc) {
                    $listap[] = new \usoCFDI($uc);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_usoCFDI_all', $listap);
        }

        return $listap;
    }

}
