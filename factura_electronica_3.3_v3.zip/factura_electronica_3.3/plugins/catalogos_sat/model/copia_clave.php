<?php

class claveProdServ extends fs_model {

    public $id_ClaveProdServ;
    public $c_ClaveProdServ;
    public $Descripcion;

    public function __construct($c = FALSE) {
        parent::__construct('c_claveprodserv');
        if ($c) {
            $this->id_ClaveProdServ = $c['id_ClaveProdServ'];
            $this->c_ClaveProdServ = $c['c_ClaveProdServ'];
            $this->Descripcion = $c['Descripcion'];
        } else {
            $this->id_ClaveProdServ = '';
            $this->c_ClaveProdServ = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_ClaveProdServ)) {
            return 'index.php?page=admin_claves';
        }

        return 'index.php?page=admin_claves#' . $this->id_ClaveProdServ;
    }

    
    public function is_default() {
        return ( $this->id_ClaveProdServ == $this->default_items->id_ClaveProdServ() );
    }

    
    public function get($cod) {
        $clave = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_ClaveProdServ = " . $this->var2str($cod) . ";");
        if ($clave) {
            return new \claveProdServ($clave[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $clave = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_ClaveProdServ = " . $this->var2str($cod) . ";");
        if ($clave) {
            return new \claveProdServ($clave[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_ClaveProdServ)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_ClaveProdServ = " . $this->var2str($this->id_ClaveProdServ) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_ClaveProdServ = trim($this->id_ClaveProdServ);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion no válida.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_ClaveProdServ = " . $this->var2str($this->c_ClaveProdServ) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_ClaveProdServ = " . $this->var2str($this->id_ClaveProdServ) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_ClaveProdServ,c_ClaveProdServ,Descripcion) VALUES
                     (" . $this->var2str($this->id_ClaveProdServ) .
                        "," . $this->var2str($this->c_ClaveProdServ) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_ClaveProdServ = " . $this->var2str($this->id_ClaveProdServ) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_clave_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_clave_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_ClaveProdServ ASC;");
            if ($data) {
                foreach ($data as $c) {
                    $listap[] = new \claveProdServ($c);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_clave_all', $listap);
        }

        return $listap;
    }


    public function search($query = '', $offset = 0, $id_ClaveProdServ = '', $c_ClaveProdServ = '', $Descripcion = '') {
        $claveslist = array();
        $query = $this->no_html(mb_strtolower($query, 'UTF8'));

        if ($query != '' AND $offset == 0 AND $id_ClaveProdServ == '' AND $Descripcion == '' AND ! $c_ClaveProdServ) {
            /// intentamos obtener los datos de memcache
            if ($this->new_search_tag($query)) {
                $claveslist = $this->cache->get_array('claves_search_' . $query);
            }
        }

        if (count($claveslist) <= 1) {
            $sql = "SELECT id_ClaveProdServ,c_ClaveProdServ,Descripcions FROM " . $this->table_name;
            $separador = ' WHERE';

            if ($id_ClaveProdServ != '') {
                $sql .= $separador . " id_ClaveProdServ = " . $this->var2str($id_ClaveProdServ);
                $separador = ' AND';
            }

            if ($Descripcion != '') {
                $sql .= $separador . "Descripcion = " . $this->var2str($Descripcion);
                $separador = ' AND';
            }

            if ($c_ClaveProdServ) {
                $sql .= $separador . "c_ClaveProdServ = " . $this->var2str($c_ClaveProdServ);
                $separador = ' AND';
            }

            if ($query == '') {
                /// nada
            } else if (is_numeric($query)) {
                $sql .= $separador . " (id_ClaveProdServ = " . $this->var2str($query)
                        . " OR id_ClaveProdServ LIKE '%" . $this->var2str($query) . "%'"
                        . " OR c_ClaveProdServ LIKE '%" . $this->var2str($query) . "%'"
                        . " OR Descripcion LIKE '%" . $this->var2str($query) . ")";
                $separador = ' AND';
            } else {
                /// ¿La búsqueda son varias palabras?
                $palabras = explode(' ', $query);
                if (count($palabras) > 1) {
                    $sql .= $separador . " (lower(id_ClaveProdServ) = " . $this->var2str($query)
                            . " OR lower(id_ClaveProdServ) LIKE '%" . $this->var2str($query) . "%'"
                            . " OR lower(c_ClaveProdServ) LIKE '%" . $this->var2str($query) . "%'"
                            . " OR lower(Descripcion) LIKE '%" . $this->var2str($query) . "%'"
                            . " OR (";

                    foreach ($palabras as $i => $pal) {
                        if ($i == 0) {
                            $sql .= "lower(descripcion) LIKE '%" . $pal . "%'";
                        } else {
                            $sql .= " AND lower(descripcion) LIKE '%" . $pal . "%'";
                        }
                    }

                    $sql .= "))";
                } else {
                    $sql .= $separador . " (lower(id_ClaveProdServ) = " . $this->var2str($query)
                            . " OR lower(id_ClaveProdServ) LIKE '%" . $this->var2str($query) . "%'"
                            . " OR lower(c_ClaveProdServ) LIKE '%" . $this->var2str($query) . "%'"
                            . " OR lower(Descripcion) LIKE '%" . $this->var2str($query) . "%')";
                }
            }

            if (strtolower(FS_DB_TYPE) == 'mysql') {
                $sql .= " ORDER BY lower(id_ClaveProdServ) ASC";
            } else {
                $sql .= " ORDER BY id_ClaveProdServ ASC";
            }

            $data = $this->db->select_limit($sql, FS_ITEM_LIMIT, $offset);
            if ($data) {
                foreach ($data as $a) {
                    $claveslist[] = new \claveProdServ($a);
                }
            }
        }

        return $claveslist;
    }


    private function new_search_tag($tag) {
        $encontrado = FALSE;
        $actualizar = FALSE;

        if (strlen($tag) > 1) {
            /// obtenemos los datos de memcache
            $this->get_search_tags();

            foreach (self::$search_tags as $i => $value) {
                if ($value['tag'] == $tag) {
                    $encontrado = TRUE;
                    if (time() + 5400 > $value['expires'] + 300) {
                        self::$search_tags[$i]['count'] ++;
                        self::$search_tags[$i]['expires'] = time() + (self::$search_tags[$i]['count'] * 5400);
                        $actualizar = TRUE;
                    }
                    break;
                }
            }
            if (!$encontrado) {
                self::$search_tags[] = array('tag' => $tag, 'expires' => time() + 5400, 'count' => 1);
                $actualizar = TRUE;
            }

            if ($actualizar) {
                $this->cache->set('claves_searches', self::$search_tags, 5400);
            }
        }

        return $encontrado;
    }


    public function get_search_tags() {
        if (!isset(self::$search_tags)) {
            self::$search_tags = $this->cache->get_array('claves_searches');
        }

        return self::$search_tags;
    }

}
