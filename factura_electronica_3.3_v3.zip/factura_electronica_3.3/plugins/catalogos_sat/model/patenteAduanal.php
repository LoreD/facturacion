<?php

class patenteAduanal extends fs_model {

    public $id_PatenteAduanal;
    public $c_PatenteAduanal;

    public function __construct($p = FALSE) {
        parent::__construct('c_patenteaduanal');
        if ($p) {
            $this->id_PatenteAduanal = $p['id_PatenteAduanal'];
            $this->c_PatenteAduanal = $p['c_PatenteAduanal'];
        } else {
            $this->id_PatenteAduanal = '';
            $this->c_PatenteAduanal = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_PatenteAduanal)) {
            return 'index.php?admin_patentesAduanal';
        }

        return 'index.php?admin_patentesAduanal#' . $this->id_PatenteAduanal;
    }

    
    public function is_default() {
        return ( $this->id_PatenteAduanal == $this->default_items->id_PatenteAduanal() );
    }

    
    public function get($cod) {
        $patente = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_PatenteAduanal = " . $this->var2str($cod) . ";");
        if ($patente) {
            return new \patenteAduanal($patente[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $patente = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_PatenteAduanal = " . $this->var2str($cod) . ";");
        if ($patente) {
            return new \patenteAduanal($patente[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_PatenteAduanal)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_PatenteAduanal = " . $this->var2str($this->id_PatenteAduanal) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_PatenteAduanal = trim($this->id_PatenteAduanal);
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_PatenteAduanal = " . $this->var2str($this->c_PatenteAduanal) .
                        "  WHERE id_PatenteAduanal = " . $this->var2str($this->id_PatenteAduanal) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_PatenteAduanal,c_PatenteAduanal) VALUES
                     (" . $this->var2str($this->id_PatenteAduanal) .
                        "," . $this->var2str($this->c_PatenteAduanal) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_PatenteAduanal = " . $this->var2str($this->id_PatenteAduanal) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_patente_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_patente_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_PatenteAduanal ASC LIMIT 20;");
            if ($data) {
                foreach ($data as $p) {
                    $listap[] = new \patenteAduanal($p);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_patente_all', $listap);
        }

        return $listap;
    }

}
