<?php

class metodoPago extends fs_model {

    public $id_MetodoPago;
    public $c_MetodoPago;
    public $Descripcion;

    public function __construct($a = FALSE) {
        parent::__construct('c_metodopago');
        if ($a) {
            $this->id_MetodoPago = $a['id_MetodoPago'];
            $this->c_MetodoPago = $a['c_MetodoPago'];
            $this->Descripcion = $a['Descripcion'];
        } else {
            $this->id_MetodoPago = '';
            $this->c_MetodoPago = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_MetodoPago)) {
            return 'index.php?page=admin_metodosPago';
        }

        return 'index.php?page=admin_metodosPago#' . $this->id_MetodoPago;
    }

    
    public function is_default() {
        return ( $this->id_MetodoPago == $this->default_items->id_MetodoPago() );
    }

    
    public function get($cod) {
        $metodoPago = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_MetodoPago = " . $this->var2str($cod) . ";");
        if ($metodoPago) {
            return new \metodoPago($metodoPago[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $metodoPago = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_MetodoPago = " . $this->var2str($cod) . ";");
        if ($metodoPago) {
            return new \metodoPago($metodoPago[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_MetodoPago)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_MetodoPago = " . $this->var2str($this->id_MetodoPago) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_MetodoPago = trim($this->id_MetodoPago);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion del país no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_MetodoPago = " . $this->var2str($this->c_MetodoPago) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_MetodoPago = " . $this->var2str($this->id_MetodoPago) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_MetodoPago,c_MetodoPago,Descripcion) VALUES
                     (" . $this->var2str($this->id_MetodoPago) .
                        "," . $this->var2str($this->c_MetodoPago) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_MetodoPago = " . $this->var2str($this->id_MetodoPago) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_metodoPago_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_metodoPago_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_MetodoPago ASC;");
            if ($data) {
                foreach ($data as $a) {
                    $listap[] = new \metodoPago($a);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_metodoPago_all', $listap);
        }

        return $listap;
    }

}
