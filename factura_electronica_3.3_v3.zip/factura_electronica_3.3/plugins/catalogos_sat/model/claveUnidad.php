<?php

class claveUnidad extends fs_model {

    public $id_ClaveUnidad;
    public $c_ClaveUnidad;
    public $Nombre;
    public $Descripcion;
    public $Simbolo;

    public function __construct($cu = FALSE) {
        parent::__construct('c_claveunidad');
        if ($cu) {
            $this->id_ClaveUnidad = $cu['id_ClaveUnidad'];
            $this->c_ClaveUnidad = $cu['c_ClaveUnidad'];
            $this->Nombre = $cu['Nombre'];
            $this->Descripcion = $cu['Descripcion'];
            $this->Simbolo = $cu['Simbolo'];
        } else {
            $this->id_ClaveUnidad = '';
            $this->c_ClaveUnidad = '';
            $this->Nombre = '';
            $this->Descripcion = '';
            $this->Simbolo = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_ClaveUnidad)) {
            return 'index.php?page=admin_clavesUnidad';
        }

        return 'index.php?page=admin_clavesUnidad#' . $this->id_ClaveUnidad;
    }

    
    public function is_default() {
        return ( $this->id_ClaveUnidad == $this->default_items->id_ClaveUnidad() );
    }

    
    public function get($cod) {
        $clave = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_ClaveUnidad = " . $this->var2str($cod) . ";");
        if ($clave) {
            return new \claveUnidad($clave[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $clave = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_ClaveUnidad = " . $this->var2str($cod) . ";");
        if ($clave) {
            return new \claveUnidad($clave[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_ClaveUnidad)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_ClaveUnidad = " . $this->var2str($this->id_ClaveUnidad) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_ClaveUnidad = trim($this->id_ClaveUnidad);
        $this->Nombre = $this->no_html($this->Nombre);

        if (strlen($this->Nombre) < 1) {
            $this->new_error_msg("Nombre no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_ClaveUnidad = " . $this->var2str($this->c_ClaveUnidad) .
                        ", Nombre = " . $this->var2str($this->Nombre) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        ", Simbolo = " . $this->var2str($this->Simbolo) .
                        "  WHERE id_ClaveUnidad = " . $this->var2str($this->id_ClaveUnidad) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_ClaveUnidad,c_ClaveUnidad,Nombre,Descripcion,Simbolo) VALUES
                     (" . $this->var2str($this->id_ClaveUnidad) .
                        "," . $this->var2str($this->c_ClaveUnidad) .
                        "," . $this->var2str($this->Nombre) .
                        "," . $this->var2str($this->Descripcion) .
                        "," . $this->var2str($this->Simbolo) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_ClaveUnidad = " . $this->var2str($this->id_ClaveUnidad) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_claveUnidad_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_claveUnidad_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_ClaveUnidad ASC LIMIT 20;");
            if ($data) {
                foreach ($data as $cu) {
                    $listap[] = new \claveUnidad($cu);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_claveUnidad_all', $listap);
        }
        return $listap;
    }





    public function search_unidad($query, $offset = 0) {
        $unidadlist = array();
        $query = mb_strtolower($this->no_html($query), 'UTF8');

        $consulta = "SELECT * FROM " . $this->table_name . " WHERE ";
        if (is_numeric($query)) {
            $consulta .= "(c_ClaveUnidad LIKE '%" . $query . "%' OR id_ClaveUnidad LIKE '%" . $query . "%'"
                    . " OR Nombre LIKE '%" . $query . "%')";
        } else {
            $buscar = str_replace(' ', '%', $query);
            $consulta .= "(lower(c_ClaveUnidad) LIKE '%" . $buscar . "%' OR lower(id_ClaveUnidad) LIKE '%" . $buscar . "%'"
                    . " OR lower(Nombre) LIKE '%" . $buscar . "%')";
        }
        $consulta .= " GROUP BY c_ClaveUnidad ORDER BY lower(id_ClaveUnidad) ASC";

        $data = $this->db->select_limit($consulta, FS_ITEM_LIMIT, $offset);
        if ($data) {
            foreach ($data as $d) {
                $unidadlist[] = new \claveUnidad($d);
            }
        }

        return $unidadlist;
    }

}
