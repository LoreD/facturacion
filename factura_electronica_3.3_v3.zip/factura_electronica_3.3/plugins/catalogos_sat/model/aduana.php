<?php

class aduana extends fs_model {

    public $id_Aduana;
    public $c_Aduana;
    public $Descripcion;

    public function __construct($a = FALSE) {
        parent::__construct('c_aduana');
        if ($a) {
            $this->id_Aduana = $a['id_Aduana'];
            $this->c_Aduana = $a['c_Aduana'];
            $this->Descripcion = $a['Descripcion'];
        } else {
            $this->id_Aduana = '';
            $this->c_Aduana = '';
            $this->Descripcion = '';
        }
    }

    public function install() {
        $this->clean_cache();
    }

    
    public function url() {
        if (is_null($this->id_Aduana)) {
            return 'index.php?page=admin_aduanas';
        }

        return 'index.php?page=admin_aduanas#' . $this->id_Aduana;
    }

    
    public function is_default() {
        return ( $this->id_Aduana == $this->default_items->id_Aduana() );
    }

    
    public function get($cod) {
        $aduana = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_Aduana = " . $this->var2str($cod) . ";");
        if ($aduana) {
            return new \aduana($aduana[0]);
        }

        return FALSE;
    }

   
    
    public function get_by_iso($cod) {
        $aduana = $this->db->select("SELECT * FROM " . $this->table_name . " WHERE c_Aduana = " . $this->var2str($cod) . ";");
        if ($aduana) {
            return new \aduana($aduana[0]);
        }

        return FALSE;
    }

    
    public function exists() {
        if (is_null($this->id_Aduana)) {
            return FALSE;
        }

        return $this->db->select("SELECT * FROM " . $this->table_name . " WHERE id_Aduana = " . $this->var2str($this->id_Aduana) . ";");
    }

    
    public function test() {
        $status = FALSE;

        $this->id_Aduana = trim($this->id_Aduana);
        $this->Descripcion = $this->no_html($this->Descripcion);

        if (strlen($this->Descripcion) < 1) {
            $this->new_error_msg("Descripcion del país no válido.");
        } else
            $status = TRUE;

        return $status;
    }

    
    public function save() {
        if ($this->test()) {
            $this->clean_cache();

            if ($this->exists()) {
                $sql = "UPDATE " . $this->table_name . " SET c_Aduana = " . $this->var2str($this->c_Aduana) .
                        ", Descripcion = " . $this->var2str($this->Descripcion) .
                        "  WHERE id_Aduana = " . $this->var2str($this->id_Aduana) . ";";
            } else {
                $sql = "INSERT INTO " . $this->table_name . " (id_Aduana,c_Aduana,Descripcion) VALUES
                     (" . $this->var2str($this->id_Aduana) .
                        "," . $this->var2str($this->c_Aduana) .
                        "," . $this->var2str($this->Descripcion) . ");";
            }

            return $this->db->exec($sql);
        }

        return FALSE;
    }

    
    public function delete() {
        $this->clean_cache();
        return $this->db->exec("DELETE FROM " . $this->table_name . " WHERE id_Aduana = " . $this->var2str($this->id_Aduana) . ";");
    }

    
    private function clean_cache() {
        $this->cache->delete('m_aduana_all');
    }


    public function all() {
        /// Leemos la lista de la caché
        $listap = $this->cache->get_array('m_aduana_all');
        if (empty($listap)) {
            /// si no encontramos los datos en caché, leemos de la base de datos
            $data = $this->db->select("SELECT * FROM " . $this->table_name . " ORDER BY id_Aduana ASC;");
            if ($data) {
                foreach ($data as $a) {
                    $listap[] = new \aduana($a);
                }
            }

            /// guardamos la lista en caché
            $this->cache->set('m_aduana_all', $listap);
        }

        return $listap;
    }

}
